# archfi

Just a simple bash script wizard to install Arch Linux after you have booted on the official Arch Linux install media.

With this script, you can install Arch Linux with 2 lines of code.

This wizard is maked to install minimum packages (base, grub and optionally efibootmgr).
At the end of this wizard, you can install or launch archdi (Arch Linux Destop Install) to install and configure desktop packages.
archdi project : https://github.com/MatMoul/archdi

You can watch my videos to show how to use it :
https://www.youtube.com/playlist?list=PLytHgIKLV1caHlCrcTSkm5OF2WSVI1_Sq

How to use :
Boot with the Arch Linux image : https://www.archlinux.org/download/

Download the script :
wget archfi.sf.net/archfi
or if sourceforge is down :
wget matmoul.github.io/archfi

And launch the script :
sh archfi
