#Translations

Translations is simple...<br />
Fork the project.<br />
Create your language file.<br />
Pull Request your change.

You can test your change with the next command :<br />
sh archfi {githubusername} {branchname}<br />
As exemple :<br />
sh archfi matmoul master
