# condres-installer-cli fork to archfi

Just a simple bash script wizard to install Condres Linux after you have booted on the official Condres Linux install media.

With this script, you can install Condres Linux with two simple terminal commands.

This wizard is made to install minimum packages (Base, GRUB, and optionally efibootmgr).<br />
At the end of this wizard, you can install or launch [archdi](https://github.com/MatMoul/archdi) (Condres Linux Destop Install) to install and configure desktop packages.<br />


To start the cli installer just do

# liveuser

# sudo su

# setup

Here the text installer will appear directly.


