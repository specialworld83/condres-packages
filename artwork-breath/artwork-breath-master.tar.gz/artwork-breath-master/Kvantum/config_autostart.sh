#!/bin/bash 

mkdir ~/.config/Kvantum
cp -rv /usr/share/Kvantum/kvantum.kvconfig ~/.config/Kvantum/
