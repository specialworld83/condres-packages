Breath Theme
=============

Breath Look & Feel package.

## Contents

* Color scheme
* Icons, based on Breeze https://cgit.kde.org/breeze-icons.git/
* Plasma theme
* Sddm theme, lock screen and splash screen based on Breeze.
* Breath wallpaper

![Alt text](/lookandfeel/contents/previews/preview.png?raw=true)
