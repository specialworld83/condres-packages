Global assets for Apricity OS
