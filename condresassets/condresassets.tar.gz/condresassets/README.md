Global assets for Condres OS
