<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl" version="2.1">
<context>
    <name>AccountTypeDialog</name>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="14"/>
        <source>Account Type</source>
        <translation>Rodzaj konta</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="64"/>
        <source>Standard</source>
        <translation>Standardowe</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="69"/>
        <source>Administrator</source>
        <translation>Administrator</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="79"/>
        <source>Show Groups</source>
        <translation>Pokaż grupy</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="93"/>
        <source>Group</source>
        <translation>Grupa</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="98"/>
        <source>Member</source>
        <translation>Uczestnik</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="115"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="135"/>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="136"/>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="167"/>
        <source>Warning!</source>
        <translation>Uwaga!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="137"/>
        <source>Admin group %1 isn&apos;t enabled in &apos;%2&apos;! You have to enable it to be able to set admin rights...</source>
        <translation>Grupa administracyjna %1 nie występuje w pliku &apos;%2&apos;! Należy ją uaktywnić, aby mieć możliwość nadawania uprawnień administracyjnych...</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="168"/>
        <source>Following default user groups have been disabled:
%1
It is recommended to enable those groups. Do you really want to continue?</source>
        <translation>Następujące domyślne grupy użytkowników zostały wyłączone:
%1
Zaleca się, aby były one włączone. Czy na pewno chcesz kontynuować?</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Error!</source>
        <translation>Błąd!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Failed to set groups!</source>
        <translation>Ustawianie grup nie powiodło się!</translation>
    </message>
</context>
<context>
    <name>ActionDialog</name>
    <message>
        <location filename="../ActionDialog.cpp" line="39"/>
        <source>Do you really want to continue?</source>
        <translation>Czy na pewno chcesz kontynuować?</translation>
    </message>
    <message>
        <location filename="../ActionDialog.cpp" line="87"/>
        <source>Done ...</source>
        <translation>Ukończone...</translation>
    </message>
</context>
<context>
    <name>AddUserDialog</name>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="14"/>
        <source>Add User</source>
        <translation>Dodaj użytkownika</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="71"/>
        <source>Username</source>
        <translation>Nazwa użytkownika</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="93"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="115"/>
        <source>Retype Password</source>
        <translation>Hasło (ponownie)</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="164"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="184"/>
        <source>Create</source>
        <translation>Utwórz</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="87"/>
        <source>Your username contains invalid characters!</source>
        <translation>Nazwa użytkownika zawiera niedozwolone znaki!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="91"/>
        <source>Your passwords do not match!</source>
        <translation>Hasła nie są identyczne!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="96"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Error!</source>
        <translation>Błąd!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <source>Failed to add user!</source>
        <translation>Dodawanie użytkownika nie powiodło się!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>Ustawienie hasła użytkownika nie powiodło się!</translation>
    </message>
</context>
<context>
    <name>ChangePasswordDialog</name>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="14"/>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="74"/>
        <source>New Password</source>
        <translation>Nowe hasło</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="96"/>
        <source>Retype Password</source>
        <translation>Wpisz hasło ponownie</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="129"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="149"/>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Error!</source>
        <translation>Błąd!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <source>Your passwords do not match!</source>
        <translation>Twoje hasła nie są zgodne!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>Ustawienie hasła użytkownika nie powiodło się!</translation>
    </message>
</context>
<context>
    <name>KernelCommon</name>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="39"/>
        <source>Kernel</source>
        <translation>Jądro</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="46"/>
        <source>Add and remove Condres kernels</source>
        <translation>Dodawaj i usuwaj jądra systemowe</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="77"/>
        <source>Install Linux %1</source>
        <translation>Zainstaluj Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="78"/>
        <source>The following packages will be installed:</source>
        <translation>Następujące pakiety zostaną zainstalowane:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="113"/>
        <source>Remove Linux %1</source>
        <translation>Usuń Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="114"/>
        <source>The following packages will be removed:</source>
        <translation>Następujące pakiety zostaną usunięte:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="146"/>
        <source>Linux %1.%2 changelog</source>
        <translation>Lista zmian Linux %1.%2</translation>
    </message>
</context>
<context>
    <name>KernelListViewDelegate</name>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="95"/>
        <source>LTS</source>
        <translation>Długi okres wsparcia</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="96"/>
        <source>Recommended</source>
        <translation>Polecany</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="97"/>
        <source>Running</source>
        <translation>Działający</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="98"/>
        <source>Installed</source>
        <translation>Zainstalowany</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="99"/>
        <source>Unsupported</source>
        <translation>Niewspierany</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="102"/>
        <source>Real-time</source>
        <translation>W czasie rzeczywistym</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="200"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="271"/>
        <source>Changelog</source>
        <translation>Lista zmian</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="100"/>
        <source>Custom</source>
        <translation>Własny</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="101"/>
        <source>Experimental</source>
        <translation>Eksperymentalny</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="198"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="269"/>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="199"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="270"/>
        <source>Install</source>
        <translation>Zainstaluj</translation>
    </message>
</context>
<context>
    <name>KeyboardCommon</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="33"/>
        <source>Keyboard Settings</source>
        <translation>Ustawienia klawiatury</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="40"/>
        <source>Keyboard settings</source>
        <translation>Ustawienia klawiatury</translation>
    </message>
</context>
<context>
    <name>KeyboardModel</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="220"/>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="264"/>
        <source>Default</source>
        <translation>Domyślnie</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="306"/>
        <source>Default Keyboard Model</source>
        <translation>Domyślny model klawiatury</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="515"/>
        <source>Error!</source>
        <translation>Błąd!</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="516"/>
        <source>Failed to set keyboard layout</source>
        <translation>Wystąpił błąd przy ustawianiu układu klawiatury</translation>
    </message>
</context>
<context>
    <name>LanguageListViewDelegate</name>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="96"/>
        <source>Display Language</source>
        <translation>Wyświetlany język</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="99"/>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="101"/>
        <source>Collation and Sorting</source>
        <translation>Zestawienie i sortowanie</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="102"/>
        <source>Messages</source>
        <translation>Wiadomości</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="132"/>
        <source>Formats</source>
        <translation>Formaty</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="135"/>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="136"/>
        <source>Identification</source>
        <translation>Identyfikacja</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="137"/>
        <source>Measurement Units</source>
        <translation>Jednostki miary</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="138"/>
        <source>Currency</source>
        <translation>Waluta</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="139"/>
        <source>Names</source>
        <translation>Nazwy</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="140"/>
        <source>Numbers</source>
        <translation>Liczby</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="141"/>
        <source>Paper</source>
        <translation>Papier</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="142"/>
        <source>Telephone</source>
        <translation>Telefon</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="143"/>
        <source>Time</source>
        <translation>Czas</translation>
    </message>
</context>
<context>
    <name>LanguagePackagesCommon</name>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="45"/>
        <source>Language Packages</source>
        <translation>Pakiety językowe</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="52"/>
        <source>Detection and installation of language packages</source>
        <translation>Wykrywanie i instalacja pakietów językowych</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="107"/>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="109"/>
        <source>%1 language packages</source>
        <translation>%1 Pakietów językowych</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="160"/>
        <source>Global language packages</source>
        <translation>Pakiety ogólnojęzykowe</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="182"/>
        <source>System is out-of-date</source>
        <translation>System jest nieaktualny</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="183"/>
        <source>Your System is not up-to-date! You have to update it first to continue!</source>
        <translation>Twój system jest nieaktualny. Zaktualizuj go, aby kontynuować!</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="215"/>
        <source>Install language packages.</source>
        <translation>Zainstaluj pakiety językowe.</translation>
    </message>
</context>
<context>
    <name>LocaleCommon</name>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="33"/>
        <source>Locale Settings</source>
        <translation>Ustawienia lokalne</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="40"/>
        <source>Add and configure locales</source>
        <translation>Dodaj i konfiguruj pakiety językowe</translation>
    </message>
</context>
<context>
    <name>LocaleModule</name>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="35"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="42"/>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="49"/>
        <source>Restore</source>
        <translation>Przywróć</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="62"/>
        <source>System Locales</source>
        <translation>Lokalizacje systemowe</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="125"/>
        <source>Detailed Settings</source>
        <translation>Ustawienia szczegółowe</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="170"/>
        <source>Display Language</source>
        <translation>Wyświetlany język</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="188"/>
        <source>Language:</source>
        <translation>Język:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="198"/>
        <source>Collation and Sorting:</source>
        <translation>Zestawienie i sortowanie:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="208"/>
        <source>Messages:</source>
        <translation>Wiadomości:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="218"/>
        <source>CType:</source>
        <translation>CType:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="231"/>
        <source>Formats</source>
        <translation>Formaty</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="249"/>
        <source>Numbers:</source>
        <translation>Liczby:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="259"/>
        <source>Time:</source>
        <translation>Czas:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="269"/>
        <source>Currency:</source>
        <translation>Waluta:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="279"/>
        <source>Measurement Units:</source>
        <translation>Jednostki miary:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="289"/>
        <source>Address:</source>
        <translation>Adres:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="299"/>
        <source>Names:</source>
        <translation>Nazwy:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="309"/>
        <source>Telephone:</source>
        <translation>Telefon:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="319"/>
        <source>Identification:</source>
        <translation>Identyfikacja:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="329"/>
        <source>Paper:</source>
        <translation>Papier:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="363"/>
        <source>Set as default display language and format</source>
        <translation>Ustaw jako domyślny język i format</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="368"/>
        <source>Set as default display language</source>
        <translation>Ustaw jako domyślny język wyświetlania</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="373"/>
        <source>Set as default format</source>
        <translation>Ustaw jako domyślny format</translation>
    </message>
</context>
<context>
    <name>MhwdCommon</name>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="39"/>
        <source>Hardware Configuration</source>
        <translation>Konfiguracja sprzętowa</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="46"/>
        <source>Condres Hardware Detection graphical user interface</source>
        <translation>Graficzny interfejs użytkownika wykrywania sprzętu Condres</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="83"/>
        <source>Unknown device name</source>
        <translation>Nieznana nazwa urządzenia</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="142"/>
        <source>Install configuration</source>
        <translation>Zainstaluj konfigurację</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="143"/>
        <source>MHWD will install the &apos;%1&apos; configuration</source>
        <translation>MHWD zainstaluje konfigurację &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="165"/>
        <source>Install open-source graphic driver</source>
        <translation>Zainstaluj otwartoźródłowy sterownik graficzny</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="166"/>
        <source>MHWD will autodetect your open-source graphic drivers and install it</source>
        <translation>MHWD automatycznie wykryje otwartoźródłowe sterowniki dla Twojej karty graficznej i je zainstaluje</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="187"/>
        <source>Install proprietary graphic driver</source>
        <translation>Zainstaluj własnościowy sterownik graficzny</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="188"/>
        <source>MHWD will autodetect your proprietary graphic drivers and install it</source>
        <translation>MHWD automatycznie wykryje własnościowe sterowniki dla Twojej karty graficznej i je zainstaluje</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="209"/>
        <source>Reinstall configuration</source>
        <translation>Przeinstaluj konfigurację</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="210"/>
        <source>MHWD will reinstall the &apos;%1&apos; configuration</source>
        <translation>MHWD przeinstaluje konfigurację &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="232"/>
        <source>Remove configuration</source>
        <translation>Usuń konfigurację</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="233"/>
        <source>MHWD will remove the &apos;%1&apos; configuration</source>
        <translation>MHWD usunie konfigurację &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>MsmCommon</name>
    <message>
        <location filename="../MsmCommon.cpp" line="26"/>
        <source>Please use &lt;a href=&apos;%1&apos;&gt;%1&lt;/a&gt; to report bugs.</source>
        <translation>Prosimy użyć &lt;a href=&apos;%1&apos;&gt;%1&lt;/a&gt; do zgłaszania błędów.</translation>
    </message>
</context>
<context>
    <name>MsmWindow</name>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="14"/>
        <source>Condres Settings Manager</source>
        <translation>Menedżer ustawień Condres</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="185"/>
        <source>All Settings</source>
        <translation>Wszystkie ustawienia</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="211"/>
        <location filename="../../msm/MsmWindow.ui" line="235"/>
        <source>Quit</source>
        <translation>Zakończ</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="224"/>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="44"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="50"/>
        <source>Hardware</source>
        <translation>Sprzęt</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="153"/>
        <source>Condres Settings</source>
        <translation>Ustawienia Condres</translation>
    </message>
</context>
<context>
    <name>Notifier</name>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="47"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="47"/>
        <source>Kernels</source>
        <translation>Jądra</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="51"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="51"/>
        <source>Language packages</source>
        <translation>Pakiety językowe</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="55"/>
        <source>Quit</source>
        <translation>Zakończ</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="59"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="56"/>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="191"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="230"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="238"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="291"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="40"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="181"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="220"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="228"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="281"/>
        <source>Condres Settings Manager</source>
        <translation>Menedżer ustawień Condres</translation>
    </message>
    <message numerus="yes">
        <location filename="../../notifier/notifier/Notifier.cpp" line="192"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="182"/>
        <source>%n new additional language package(s) available</source>
        <translation><numerusform>Dostępny jest %n nowy, dodatkowy pakiet językowy</numerusform><numerusform>Dostępne są %n nowe dodatkowe pakiety językowe</numerusform><numerusform>Dostępnych jest %n nowych dodatkowych pakietów językowych</numerusform><numerusform>Dostępnych jest %n nowych dodatkowych pakietów językowych</numerusform></translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="231"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="221"/>
        <source>Running an unsupported kernel, please update.</source>
        <translation>Używane jest nieobsługiwane jądro, prosimy go zaktualizować.</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="239"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="229"/>
        <source>Unsupported kernel installed in your system, please remove it.</source>
        <translation>W Twoim systemie jest zainstalowane nieobsługiwane jądro, prosimy o jego usunięcie.</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="292"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="282"/>
        <source>Newer kernel is available, please update.</source>
        <translation>Dostępne jest nowsze jądro, prosimy o jego aktualizację.</translation>
    </message>
</context>
<context>
    <name>NotifierSettingsDialog</name>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="20"/>
        <source>Kernel Notifications</source>
        <translation>Powiadomienia jąder</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="26"/>
        <source>Check unsupported kernels</source>
        <translation>Sprawdź nieobsługiwane jądra</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="51"/>
        <source>Only notify if running an unsupported kernel</source>
        <translation>Powiadamiaj tylko o używanym nieobsługiwanym jądrze</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="60"/>
        <source>Check new kernels</source>
        <translation>Sprawdź nowe wydania jądra</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="85"/>
        <source>Only notify LTS kernels</source>
        <translation>Powiadamiaj tylko o jądrach z długim okresem wsparcia</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="112"/>
        <source>Only notify recommended kernels</source>
        <translation>Powiadamiaj tylko o polecanych jądrach</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="124"/>
        <source>Language Packs Notifications</source>
        <translation>Powiadomienia pakietów językowych</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="130"/>
        <source>Check missing language packs</source>
        <translation>Sprawdź brakujące pakiety językowe</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="168"/>
        <source>Quit</source>
        <translation>Zakończ</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="181"/>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="32"/>
        <source>Notifications settings</source>
        <translation>Ustawienia powiadomień</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="107"/>
        <source>Format error when saving your notifications settings</source>
        <translation>Wystąpił błąd formatu podczas zapisywania Twoich ustawień powiadomień</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="111"/>
        <source>Access error when saving your notifications settings</source>
        <translation>Wystąpił błąd dostępu podczas zapisywania Twoich ustawień powiadomień</translation>
    </message>
</context>
<context>
    <name>PageKeyboard</name>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="25"/>
        <source>Keyboard Model:</source>
        <translation>Model klawiatury:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="131"/>
        <source>Type here to test your keyboard</source>
        <translation>Użyj tego pola, aby przetestować układ klawiatury</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="140"/>
        <source>Delay:</source>
        <translation>Opóźnienie:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="158"/>
        <source>Delay</source>
        <translation>Opóźnienie</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="165"/>
        <source>Set delay</source>
        <translation>Ustaw opóźnienie</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="183"/>
        <source>Rate:</source>
        <translation>Ocena:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="201"/>
        <source>Rate  </source>
        <translation>Ocena</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="208"/>
        <source>Set Rate</source>
        <translation>Oceń</translation>
    </message>
</context>
<context>
    <name>PageLanguagePackages</name>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="24"/>
        <source>Available Language Packages</source>
        <translation>Dostępne pakiety językowe</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="32"/>
        <source>Additional language packages can be installed:</source>
        <translation>Dodatkowe pakiety językowe gotowe do instalacji:</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="55"/>
        <source>Install Packages</source>
        <translation>Zainstaluj pakiety</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="80"/>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="128"/>
        <source>Package</source>
        <translation>Pakiet</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="85"/>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="133"/>
        <source>Parent Package</source>
        <translation>Pakiet nadrzędny</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="90"/>
        <source>Install</source>
        <translation>Zainstaluj</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="99"/>
        <source>Installed Language Packages</source>
        <translation>Zainstalowano pakiety językowe</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="105"/>
        <source>Installed language packages:</source>
        <translation>Zainstalowane pakiety językowe:</translation>
    </message>
</context>
<context>
    <name>PageMhwd</name>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="37"/>
        <source>Auto Install
Open-source Driver</source>
        <translation>Zainstaluj automatycznie
sterownik otwartoźródłowy</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="45"/>
        <source>Auto Install
Proprietary Driver</source>
        <translation>Zainstaluj automatycznie
sterownik własnościowy</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="67"/>
        <source>Driver</source>
        <translation>Sterownik</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="72"/>
        <source>Open-source</source>
        <translation>Otwartoźródłowe</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="77"/>
        <source>Installed</source>
        <translation>Zainstalowany</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="85"/>
        <source>Show all devices</source>
        <translation>Pokaż wszystkie urządzenia</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="104"/>
        <source>Reinstall</source>
        <translation>Przeinstaluj</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="94"/>
        <source>Install</source>
        <translation>Zainstaluj</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="99"/>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
</context>
<context>
    <name>PageTimeDate</name>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="20"/>
        <source>Time and Date</source>
        <translation>Czas i data</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="26"/>
        <source>Set time and date automatically</source>
        <translation>Ustaw czas i datę automatycznie</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="148"/>
        <source>Time Zone</source>
        <translation>Strefa czasowa</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="197"/>
        <source>Change Time Zone</source>
        <translation>Zmień strefę czasową</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="33"/>
        <source>Hardware clock in local time zone</source>
        <translation>Zegar czasu rzeczywistego w lokalnej strefie czasowej</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="51"/>
        <source>Time:</source>
        <translation>Czas:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="86"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="115"/>
        <source>Hardware clock:</source>
        <translation>Zegar sprzętowy:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="122"/>
        <source>Universal time:</source>
        <translation>Czas uniwersalny:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="165"/>
        <source>Time zone:</source>
        <translation>Strefa czasowa:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="206"/>
        <source>Country:</source>
        <translation>Kraj:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="246"/>
        <source>Has daylight time?</source>
        <translation>Ustawiono czas letni?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="276"/>
        <source>Is daylight time?</source>
        <translation>Jest to czas letni?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="306"/>
        <source>Has transitions?</source>
        <translation>Była zmiana czasu?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="317"/>
        <source>Next transition:</source>
        <translation>Następna zmiana czasu:</translation>
    </message>
</context>
<context>
    <name>PageUsers</name>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="154"/>
        <source>Image</source>
        <translation>Grafika</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="161"/>
        <source>Username</source>
        <translation>Nazwa użytkownika</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="168"/>
        <source>Account Type</source>
        <translation>Rodzaj konta</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="175"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="223"/>
        <source>●●●●●●</source>
        <translation>●●●●●●</translation>
    </message>
</context>
<context>
    <name>PreviewFileDialog</name>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="93"/>
        <source>Width:</source>
        <translation>Szerokość:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="94"/>
        <source>Height:</source>
        <translation>Wysokość:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="95"/>
        <source>Ratio:</source>
        <translation>Proporcja:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="96"/>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="97"/>
        <source>%1 px</source>
        <translation>%1 px</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="98"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
</context>
<context>
    <name>SelectLocalesDialog</name>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="14"/>
        <source>Add Locale</source>
        <translation>Dodaj lokalizację</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="34"/>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="70"/>
        <source>Territory</source>
        <translation>Terytorium</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="122"/>
        <source>Locale:</source>
        <translation>Lokalizacja:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="182"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="189"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
</context>
<context>
    <name>TimeDateCommon</name>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="38"/>
        <source>Time and Date</source>
        <translation>Czas i data</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="45"/>
        <source>Time and date configuration</source>
        <translation>Konfiguracja czasu i daty</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="138"/>
        <source>none</source>
        <translation>żaden</translation>
    </message>
</context>
<context>
    <name>TimeZoneDialog</name>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="14"/>
        <source>Time Zone Selection</source>
        <translation>Wybór strefy czasowej</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="25"/>
        <source>Region:</source>
        <translation>Obszar:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="61"/>
        <source>Zone:</source>
        <translation>Strefa:</translation>
    </message>
</context>
<context>
    <name>UsersCommon</name>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="47"/>
        <source>User Accounts</source>
        <translation>Konta użytkowników</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="54"/>
        <source>User accounts configuration</source>
        <translation>Konfiguracja kont użytkowników</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="135"/>
        <source>Continue?</source>
        <translation>Kontynuować?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="136"/>
        <source>Do you really want to remove the user %1?</source>
        <translation>Czy na pewno chcesz usunąć użytkownika %1?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="143"/>
        <source>Remove Home?</source>
        <translation>Usunąć katalog domowy?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="144"/>
        <source>Do you want to remove the home folder of the user %1?</source>
        <translation>Czy chcesz usunąć katalog domowy użytkownika %1?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="166"/>
        <location filename="../../modules/users/UsersCommon.cpp" line="236"/>
        <source>Error!</source>
        <translation>Błąd!</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="167"/>
        <source>Failed to remove user %1</source>
        <translation>Usunięcie użytkownika %1 nie powiodło się</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="183"/>
        <source>Images (*.png *.jpg *.bmp)</source>
        <translation>Pliki graficzne (*.png *.jpg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="237"/>
        <source>Failed to change user image</source>
        <translation>Zmiana obrazka użytkownika nie powiodła się</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="248"/>
        <source>Standard</source>
        <translation>Standardowe</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="267"/>
        <source>Administrator</source>
        <translation>Administrator</translation>
    </message>
</context>
</TS>
