<?xml version="1.0" ?><!DOCTYPE TS><TS language="ast" version="2.1">
<context>
    <name>AccountTypeDialog</name>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="14"/>
        <source>Account Type</source>
        <translation>Triba de cuenta</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="64"/>
        <source>Standard</source>
        <translation>Estándar</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="69"/>
        <source>Administrator</source>
        <translation>Alministrador</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="79"/>
        <source>Show Groups</source>
        <translation>Amosar grupos</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="93"/>
        <source>Group</source>
        <translation>Grupu</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="98"/>
        <source>Member</source>
        <translation>Miembru</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="115"/>
        <source>Cancel</source>
        <translation>Encaboxar</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="135"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="136"/>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="167"/>
        <source>Warning!</source>
        <translation>¡Avisu!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="137"/>
        <source>Admin group %1 isn&apos;t enabled in &apos;%2&apos;! You have to enable it to be able to set admin rights...</source>
        <translation>¡Nun ta habilitáu&apos;l grupu d&apos;alministración %1 en &apos;%2&apos;! Tienes d&apos;habilitalu pa poder afitar drechos alministrativos...</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="168"/>
        <source>Following default user groups have been disabled:
%1
It is recommended to enable those groups. Do you really want to continue?</source>
        <translation>Desabilitáronse los siguientes grupos d&apos;usuariu por defeutu:
%1
Aconséyase habilitar esos grupos. ¿De xuru quies siguir?</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Error!</source>
        <translation>¡Fallu!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Failed to set groups!</source>
        <translation>¡Fallu al afitar los grupos!</translation>
    </message>
</context>
<context>
    <name>ActionDialog</name>
    <message>
        <location filename="../ActionDialog.cpp" line="39"/>
        <source>Do you really want to continue?</source>
        <translation>¿De xuru que quies siguir?</translation>
    </message>
    <message>
        <location filename="../ActionDialog.cpp" line="87"/>
        <source>Done ...</source>
        <translation>Fecho ...</translation>
    </message>
</context>
<context>
    <name>AddUserDialog</name>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="14"/>
        <source>Add User</source>
        <translation>Amestar usuariu</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="71"/>
        <source>Username</source>
        <translation>Nome d&apos;usuariu</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="93"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="115"/>
        <source>Retype Password</source>
        <translation>Reescribir contraseña</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="164"/>
        <source>Cancel</source>
        <translation>Encaboxar</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="184"/>
        <source>Create</source>
        <translation>Crear</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="87"/>
        <source>Your username contains invalid characters!</source>
        <translation>¡El to nome d&apos;usuariu tien caráuteres non válidos!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="91"/>
        <source>Your passwords do not match!</source>
        <translation>¡Les tos contraseñes nun concasen!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="96"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Error!</source>
        <translation>¡Fallu!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <source>Failed to add user!</source>
        <translation>¡Fallu al amestar l&apos;usuariu!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>¡Fallu al afitar la contraseña d&apos;usuariu!</translation>
    </message>
</context>
<context>
    <name>ChangePasswordDialog</name>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="14"/>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="74"/>
        <source>New Password</source>
        <translation>Contraseña nueva</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="96"/>
        <source>Retype Password</source>
        <translation>Reescribir contraseña</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="129"/>
        <source>Cancel</source>
        <translation>Encaboxar</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="149"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Error!</source>
        <translation>¡Fallu!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <source>Your passwords do not match!</source>
        <translation>¡Les tos contraseñes nun concasen!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>¡Fallu al afitar la contraseña d&apos;usuariu!</translation>
    </message>
</context>
<context>
    <name>KernelCommon</name>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="39"/>
        <source>Kernel</source>
        <translation>Kernel</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="46"/>
        <source>Add and remove Condres kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="77"/>
        <source>Install Linux %1</source>
        <translation>Instalar Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="78"/>
        <source>The following packages will be installed:</source>
        <translation>Instalaránse los paquetes de darréu:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="113"/>
        <source>Remove Linux %1</source>
        <translation>Desaniciar Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="114"/>
        <source>The following packages will be removed:</source>
        <translation>Desaniciaránse los paquetes de darréu:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="146"/>
        <source>Linux %1.%2 changelog</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>KernelListViewDelegate</name>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="95"/>
        <source>LTS</source>
        <translation>LTS</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="96"/>
        <source>Recommended</source>
        <translation>Aconseyáu</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="97"/>
        <source>Running</source>
        <translation>Executándose</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="98"/>
        <source>Installed</source>
        <translation>Instaláu</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="99"/>
        <source>Unsupported</source>
        <translation>Ensin sofitu</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="102"/>
        <source>Real-time</source>
        <translation>Tiempu real</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="200"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="271"/>
        <source>Changelog</source>
        <translation>Rexistru de cambeos</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="100"/>
        <source>Custom</source>
        <translation>Personalizáu</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="101"/>
        <source>Experimental</source>
        <translation>Esperimental</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="198"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="269"/>
        <source>Remove</source>
        <translation>Desaniciar</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="199"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="270"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
</context>
<context>
    <name>KeyboardCommon</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="33"/>
        <source>Keyboard Settings</source>
        <translation>Axustes de tecláu</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="40"/>
        <source>Keyboard settings</source>
        <translation>Axustes de tecláu</translation>
    </message>
</context>
<context>
    <name>KeyboardModel</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="220"/>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="264"/>
        <source>Default</source>
        <translation>Por defeutu</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="306"/>
        <source>Default Keyboard Model</source>
        <translation>Modelu del tecláu por defeutu</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="515"/>
        <source>Error!</source>
        <translation>¡Fallu!</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="516"/>
        <source>Failed to set keyboard layout</source>
        <translation>Fallu al afitar la distribución del tecláu</translation>
    </message>
</context>
<context>
    <name>LanguageListViewDelegate</name>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="96"/>
        <source>Display Language</source>
        <translation>Llingua p&apos;amosar</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="99"/>
        <source>Language</source>
        <translation>Llingua</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="101"/>
        <source>Collation and Sorting</source>
        <translation>Colocación y orde</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="102"/>
        <source>Messages</source>
        <translation>Mensaxes</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="132"/>
        <source>Formats</source>
        <translation>Formatos</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="135"/>
        <source>Address</source>
        <translation>Direción</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="136"/>
        <source>Identification</source>
        <translation>Identificación</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="137"/>
        <source>Measurement Units</source>
        <translation>Unidaes de midida</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="138"/>
        <source>Currency</source>
        <translation>Moneda</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="139"/>
        <source>Names</source>
        <translation>Nomes</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="140"/>
        <source>Numbers</source>
        <translation>Númberos</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="141"/>
        <source>Paper</source>
        <translation>Papel</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="142"/>
        <source>Telephone</source>
        <translation>Teléfonu</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="143"/>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
</context>
<context>
    <name>LanguagePackagesCommon</name>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="45"/>
        <source>Language Packages</source>
        <translation>Paquetes de llingua</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="52"/>
        <source>Detection and installation of language packages</source>
        <translation>Deteición ya instalación de paquetes de llingües</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="107"/>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="109"/>
        <source>%1 language packages</source>
        <translation>%1 paquetes de llingua</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="160"/>
        <source>Global language packages</source>
        <translation>Paquetes globales de llingua</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="182"/>
        <source>System is out-of-date</source>
        <translation>El sistema nun ta anováu</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="183"/>
        <source>Your System is not up-to-date! You have to update it first to continue!</source>
        <translation>¡El to sistema nun ta anováu! Tienes d&apos;anovalu primero pa siguir.</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="215"/>
        <source>Install language packages.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>LocaleCommon</name>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="33"/>
        <source>Locale Settings</source>
        <translation>Axustes de locale</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="40"/>
        <source>Add and configure locales</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>LocaleModule</name>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="35"/>
        <source>Add</source>
        <translation>Amestar</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="42"/>
        <source>Remove</source>
        <translation>Desaniciar</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="49"/>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="62"/>
        <source>System Locales</source>
        <translation>Locales del sistema</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="125"/>
        <source>Detailed Settings</source>
        <translation>Axustes detallaos</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="170"/>
        <source>Display Language</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="188"/>
        <source>Language:</source>
        <translation>Llingua:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="198"/>
        <source>Collation and Sorting:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="208"/>
        <source>Messages:</source>
        <translation>Mensaxes:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="218"/>
        <source>CType:</source>
        <translation>CType:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="231"/>
        <source>Formats</source>
        <translation>Formatos</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="249"/>
        <source>Numbers:</source>
        <translation>Númberos:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="259"/>
        <source>Time:</source>
        <translation>Hora:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="269"/>
        <source>Currency:</source>
        <translation>Moneda:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="279"/>
        <source>Measurement Units:</source>
        <translation>Unidaes de midida:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="289"/>
        <source>Address:</source>
        <translation>Direción:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="299"/>
        <source>Names:</source>
        <translation>Nomes:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="309"/>
        <source>Telephone:</source>
        <translation>Teléfonu:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="319"/>
        <source>Identification:</source>
        <translation>Identificación:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="329"/>
        <source>Paper:</source>
        <translation>Papel:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="363"/>
        <source>Set as default display language and format</source>
        <translation>Afitar como llingua y formatu por defeutu</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="368"/>
        <source>Set as default display language</source>
        <translation>Afitar como llingua por defeutu</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="373"/>
        <source>Set as default format</source>
        <translation>Afitar como formatu por defeutu</translation>
    </message>
</context>
<context>
    <name>MhwdCommon</name>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="39"/>
        <source>Hardware Configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="46"/>
        <source>Condres Hardware Detection graphical user interface</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="83"/>
        <source>Unknown device name</source>
        <translation>Nome desconocíu de preséu</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="142"/>
        <source>Install configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="143"/>
        <source>MHWD will install the &apos;%1&apos; configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="165"/>
        <source>Install open-source graphic driver</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="166"/>
        <source>MHWD will autodetect your open-source graphic drivers and install it</source>
        <translation>MHWD auto-deteutará los tos controladores de códigu llibre ya instalarálos</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="187"/>
        <source>Install proprietary graphic driver</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="188"/>
        <source>MHWD will autodetect your proprietary graphic drivers and install it</source>
        <translation>MHWD auto-deteutará los tos controladores propietarios ya instalarálos</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="209"/>
        <source>Reinstall configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="210"/>
        <source>MHWD will reinstall the &apos;%1&apos; configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="232"/>
        <source>Remove configuration</source>
        <translation>Desaniciar configuración</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="233"/>
        <source>MHWD will remove the &apos;%1&apos; configuration</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MsmCommon</name>
    <message>
        <location filename="../MsmCommon.cpp" line="26"/>
        <source>Please use &lt;a href=&apos;%1&apos;&gt;%1&lt;/a&gt; to report bugs.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MsmWindow</name>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="14"/>
        <source>Condres Settings Manager</source>
        <translation>Xestor d&apos;axustes de Condres</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="185"/>
        <source>All Settings</source>
        <translation>Tolos axustes</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="211"/>
        <location filename="../../msm/MsmWindow.ui" line="235"/>
        <source>Quit</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="224"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="44"/>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="50"/>
        <source>Hardware</source>
        <translation>Harware</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="153"/>
        <source>Condres Settings</source>
        <translation>Axustes de Condres</translation>
    </message>
</context>
<context>
    <name>Notifier</name>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="47"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="47"/>
        <source>Kernels</source>
        <translation>Kernels</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="51"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="51"/>
        <source>Language packages</source>
        <translation>Paquetes de llingua</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="55"/>
        <source>Quit</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="59"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="56"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="191"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="230"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="238"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="291"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="40"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="181"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="220"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="228"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="281"/>
        <source>Condres Settings Manager</source>
        <translation>Xestor d&apos;axustes de Condres</translation>
    </message>
    <message numerus="yes">
        <location filename="../../notifier/notifier/Notifier.cpp" line="192"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="182"/>
        <source>%n new additional language package(s) available</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="231"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="221"/>
        <source>Running an unsupported kernel, please update.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="239"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="229"/>
        <source>Unsupported kernel installed in your system, please remove it.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="292"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="282"/>
        <source>Newer kernel is available, please update.</source>
        <translation>Hai disponible un kernel más nuevu, anueva por favor.</translation>
    </message>
</context>
<context>
    <name>NotifierSettingsDialog</name>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="20"/>
        <source>Kernel Notifications</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="26"/>
        <source>Check unsupported kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="51"/>
        <source>Only notify if running an unsupported kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="60"/>
        <source>Check new kernels</source>
        <translation>Comprobar kernels nuevos</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="85"/>
        <source>Only notify LTS kernels</source>
        <translation>Avisar namái de kernels LTS</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="112"/>
        <source>Only notify recommended kernels</source>
        <translation>Avisar namái de kernels aconseyaos</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="124"/>
        <source>Language Packs Notifications</source>
        <translation>Avisos de paquetes de llingua</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="130"/>
        <source>Check missing language packs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="168"/>
        <source>Quit</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="181"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="32"/>
        <source>Notifications settings</source>
        <translation>Axustes d&apos;avisos</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="107"/>
        <source>Format error when saving your notifications settings</source>
        <translation>Fallu de formatu al guardar los tos axustes d&apos;avisos</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="111"/>
        <source>Access error when saving your notifications settings</source>
        <translation>Fallu d&apos;accesu al guardar los tos axustes d&apos;avisos</translation>
    </message>
</context>
<context>
    <name>PageKeyboard</name>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="25"/>
        <source>Keyboard Model:</source>
        <translation>Modelu del tecláu:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="131"/>
        <source>Type here to test your keyboard</source>
        <translation>Escribi equí pa comprobar el to tecláu</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="140"/>
        <source>Delay:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="158"/>
        <source>Delay</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="165"/>
        <source>Set delay</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="183"/>
        <source>Rate:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="201"/>
        <source>Rate  </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="208"/>
        <source>Set Rate</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PageLanguagePackages</name>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="24"/>
        <source>Available Language Packages</source>
        <translation>Paquetes de llingua adicionales</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="32"/>
        <source>Additional language packages can be installed:</source>
        <translation>Paquetes de llingua adicionales que puen instalase:</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="55"/>
        <source>Install Packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="80"/>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="128"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="85"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="133"/>
        <source>Parent Package</source>
        <translation>Paquete pá</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="90"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="99"/>
        <source>Installed Language Packages</source>
        <translation>Paquetes de llingua instalaos</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="105"/>
        <source>Installed language packages:</source>
        <translation>Paquetes de llingua instalaos:</translation>
    </message>
</context>
<context>
    <name>PageMhwd</name>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="37"/>
        <source>Auto Install
Open-source Driver</source>
        <translation>Instalar automáticamente
Controlador llibre</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="45"/>
        <source>Auto Install
Proprietary Driver</source>
        <translation>Instalar automáticamente
Controlador propietariu</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="67"/>
        <source>Driver</source>
        <translation>Controlador</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="72"/>
        <source>Open-source</source>
        <translation>Llibre</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="77"/>
        <source>Installed</source>
        <translation>Instaláu</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="85"/>
        <source>Show all devices</source>
        <translation>Amosar tolos preseos</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="104"/>
        <source>Reinstall</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="94"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="99"/>
        <source>Remove</source>
        <translation>Desaniciar</translation>
    </message>
</context>
<context>
    <name>PageTimeDate</name>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="20"/>
        <source>Time and Date</source>
        <translation>Data y hora</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="26"/>
        <source>Set time and date automatically</source>
        <translation>Afitar automáticamente la data y hora</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="148"/>
        <source>Time Zone</source>
        <translation>Fusu horariu</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="197"/>
        <source>Change Time Zone</source>
        <translation>Camudar fusu horariu</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="33"/>
        <source>Hardware clock in local time zone</source>
        <translation>Reló de hardware na zona d&apos;hora llocal</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="51"/>
        <source>Time:</source>
        <translation>Hora:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="86"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="115"/>
        <source>Hardware clock:</source>
        <translation>Reló de hardware:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="122"/>
        <source>Universal time:</source>
        <translation>Hora universal:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="165"/>
        <source>Time zone:</source>
        <translation>Fusu horariu:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="206"/>
        <source>Country:</source>
        <translation>País:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="246"/>
        <source>Has daylight time?</source>
        <translation>¿Tien horariu de branu?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="276"/>
        <source>Is daylight time?</source>
        <translation>¿Ta n&apos;horariu de branu?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="306"/>
        <source>Has transitions?</source>
        <translation>¿Tien transiciones?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="317"/>
        <source>Next transition:</source>
        <translation>Transición siguiente:</translation>
    </message>
</context>
<context>
    <name>PageUsers</name>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="154"/>
        <source>Image</source>
        <translation>Semeya</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="161"/>
        <source>Username</source>
        <translation>Nome d&apos;usuariu</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="168"/>
        <source>Account Type</source>
        <translation>Triba de cuenta</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="175"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="223"/>
        <source>●●●●●●</source>
        <translation>●●●●●●</translation>
    </message>
</context>
<context>
    <name>PreviewFileDialog</name>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="93"/>
        <source>Width:</source>
        <translation>Anchor:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="94"/>
        <source>Height:</source>
        <translation>Altor:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="95"/>
        <source>Ratio:</source>
        <translation>Tasa:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="96"/>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="97"/>
        <source>%1 px</source>
        <translation>%1 px</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="98"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
</context>
<context>
    <name>SelectLocalesDialog</name>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="14"/>
        <source>Add Locale</source>
        <translation>Amestar locale</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="34"/>
        <source>Language</source>
        <translation>Llingua</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="70"/>
        <source>Territory</source>
        <translation>Territoriu</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="122"/>
        <source>Locale:</source>
        <translation>Locale:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="182"/>
        <source>Cancel</source>
        <translation>Encaboxar</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="189"/>
        <source>Add</source>
        <translation>Amestar</translation>
    </message>
</context>
<context>
    <name>TimeDateCommon</name>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="38"/>
        <source>Time and Date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="45"/>
        <source>Time and date configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="138"/>
        <source>none</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TimeZoneDialog</name>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="14"/>
        <source>Time Zone Selection</source>
        <translation>Esbilla del fusu horariu</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="25"/>
        <source>Region:</source>
        <translation>Rexón:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="61"/>
        <source>Zone:</source>
        <translation>Zona:</translation>
    </message>
</context>
<context>
    <name>UsersCommon</name>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="47"/>
        <source>User Accounts</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="54"/>
        <source>User accounts configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="135"/>
        <source>Continue?</source>
        <translation>¿Siguir?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="136"/>
        <source>Do you really want to remove the user %1?</source>
        <translation>¿De xuru que quies desaniar l&apos;usuariu %1?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="143"/>
        <source>Remove Home?</source>
        <translation>¿Desaniciar carpeta Home?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="144"/>
        <source>Do you want to remove the home folder of the user %1?</source>
        <translation>¿Quies desaniciar la carpeta home del usuariu %1?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="166"/>
        <location filename="../../modules/users/UsersCommon.cpp" line="236"/>
        <source>Error!</source>
        <translation>¡Fallu!</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="167"/>
        <source>Failed to remove user %1</source>
        <translation>Fallu al desaniciar al usuariu %1</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="183"/>
        <source>Images (*.png *.jpg *.bmp)</source>
        <translation>Imáxenes (*.png *.jpg *bmp)</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="237"/>
        <source>Failed to change user image</source>
        <translation>Fallu al camudar la imaxe d&apos;usuariu</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="248"/>
        <source>Standard</source>
        <translation>Estándar</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="267"/>
        <source>Administrator</source>
        <translation>Alministrador</translation>
    </message>
</context>
</TS>
