<?xml version="1.0" ?><!DOCTYPE TS><TS language="ro" version="2.1">
<context>
    <name>AccountTypeDialog</name>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="14"/>
        <source>Account Type</source>
        <translation>Tip cont</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="64"/>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="69"/>
        <source>Administrator</source>
        <translation>Administrator</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="79"/>
        <source>Show Groups</source>
        <translation>Arată grupuri</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="93"/>
        <source>Group</source>
        <translation>Grupă</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="98"/>
        <source>Member</source>
        <translation>Membru</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="115"/>
        <source>Cancel</source>
        <translation>Renunță</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="135"/>
        <source>Apply</source>
        <translation>Aplică</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="136"/>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="167"/>
        <source>Warning!</source>
        <translation>Atenție!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="137"/>
        <source>Admin group %1 isn&apos;t enabled in &apos;%2&apos;! You have to enable it to be able to set admin rights...</source>
        <translation>Grupul admin %1 nu este activat în „%2”! Trebuie activat pentru a putea seta drepturi de admin...</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="168"/>
        <source>Following default user groups have been disabled:
%1
It is recommended to enable those groups. Do you really want to continue?</source>
        <translation>Următoarele grupe implicite de utilizatori au fost dezactivate:
%1
Este recomandat să activați aceste grupe. Doriți să continuați?</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Error!</source>
        <translation>Eroare!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Failed to set groups!</source>
        <translation>Nu se pot seta grupele!</translation>
    </message>
</context>
<context>
    <name>ActionDialog</name>
    <message>
        <location filename="../ActionDialog.cpp" line="39"/>
        <source>Do you really want to continue?</source>
        <translation>Dorești să continui?</translation>
    </message>
    <message>
        <location filename="../ActionDialog.cpp" line="87"/>
        <source>Done ...</source>
        <translation>Terminat ...</translation>
    </message>
</context>
<context>
    <name>AddUserDialog</name>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="14"/>
        <source>Add User</source>
        <translation>Adaugă utilizator</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="71"/>
        <source>Username</source>
        <translation>Nume utilizator</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="93"/>
        <source>Password</source>
        <translation>Parolă</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="115"/>
        <source>Retype Password</source>
        <translation>Reintroduceți parola</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="164"/>
        <source>Cancel</source>
        <translation>Renunță</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="184"/>
        <source>Create</source>
        <translation>Creează</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="87"/>
        <source>Your username contains invalid characters!</source>
        <translation>Numele de utilizator conține caractere invalide!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="91"/>
        <source>Your passwords do not match!</source>
        <translation>Parolele nu se potrivesc!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="96"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Error!</source>
        <translation>Eroare!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <source>Failed to add user!</source>
        <translation>Nu se poate adăuga utilizatorul!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>Nu se poate seta parola utilizatorului!</translation>
    </message>
</context>
<context>
    <name>ChangePasswordDialog</name>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="14"/>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="74"/>
        <source>New Password</source>
        <translation>Parolă nouă</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="96"/>
        <source>Retype Password</source>
        <translation>Reintroduceți parola</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="129"/>
        <source>Cancel</source>
        <translation>Renunță</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="149"/>
        <source>Apply</source>
        <translation>Aplică</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Error!</source>
        <translation>Eroare!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <source>Your passwords do not match!</source>
        <translation>Parolele nu se potrivesc!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>Nu se poate seta parola utilizatorului!</translation>
    </message>
</context>
<context>
    <name>KernelCommon</name>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="39"/>
        <source>Kernel</source>
        <translation>Nucleu</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="46"/>
        <source>Add and remove Condres kernels</source>
        <translation>Adaugă şi şterge nuclee Condres</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="77"/>
        <source>Install Linux %1</source>
        <translation>Instalează Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="78"/>
        <source>The following packages will be installed:</source>
        <translation>Următoarele pachete vor fi instalate:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="113"/>
        <source>Remove Linux %1</source>
        <translation>Șterge Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="114"/>
        <source>The following packages will be removed:</source>
        <translation>Următoarele pachete vor fi șterse:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="146"/>
        <source>Linux %1.%2 changelog</source>
        <translation>Istoricul schimbărilor Linux %1.%2</translation>
    </message>
</context>
<context>
    <name>KernelListViewDelegate</name>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="95"/>
        <source>LTS</source>
        <translation>LTS</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="96"/>
        <source>Recommended</source>
        <translation>Recomandat</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="97"/>
        <source>Running</source>
        <translation>Rulează</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="98"/>
        <source>Installed</source>
        <translation>Instalat</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="99"/>
        <source>Unsupported</source>
        <translation>Fără suport</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="102"/>
        <source>Real-time</source>
        <translation>În timp real</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="200"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="271"/>
        <source>Changelog</source>
        <translation>Istoricul schimbărilor</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="100"/>
        <source>Custom</source>
        <translation>Personalizat</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="101"/>
        <source>Experimental</source>
        <translation>Experimental</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="198"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="269"/>
        <source>Remove</source>
        <translation>Șterge</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="199"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="270"/>
        <source>Install</source>
        <translation>Instalează</translation>
    </message>
</context>
<context>
    <name>KeyboardCommon</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="33"/>
        <source>Keyboard Settings</source>
        <translation>Setări Tastatură</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="40"/>
        <source>Keyboard settings</source>
        <translation>Setări Tastatură</translation>
    </message>
</context>
<context>
    <name>KeyboardModel</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="220"/>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="264"/>
        <source>Default</source>
        <translation>Implicit</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="306"/>
        <source>Default Keyboard Model</source>
        <translation>Model implicit de tastatură</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="515"/>
        <source>Error!</source>
        <translation>Eroare!</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="516"/>
        <source>Failed to set keyboard layout</source>
        <translation>A eșuat încercarea de a seta planul tastaturii</translation>
    </message>
</context>
<context>
    <name>LanguageListViewDelegate</name>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="96"/>
        <source>Display Language</source>
        <translation>Limbă afișaj</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="99"/>
        <source>Language</source>
        <translation>Limbă</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="101"/>
        <source>Collation and Sorting</source>
        <translation>Ordonare și sortare</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="102"/>
        <source>Messages</source>
        <translation>Mesaje</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="132"/>
        <source>Formats</source>
        <translation>Formate</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="135"/>
        <source>Address</source>
        <translation>Adrese</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="136"/>
        <source>Identification</source>
        <translation>Identificare</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="137"/>
        <source>Measurement Units</source>
        <translation>Unități de măsură</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="138"/>
        <source>Currency</source>
        <translation>Valută</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="139"/>
        <source>Names</source>
        <translation>Nume</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="140"/>
        <source>Numbers</source>
        <translation>Numere</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="141"/>
        <source>Paper</source>
        <translation>Hârtie</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="142"/>
        <source>Telephone</source>
        <translation>Telefon</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="143"/>
        <source>Time</source>
        <translation>Oră</translation>
    </message>
</context>
<context>
    <name>LanguagePackagesCommon</name>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="45"/>
        <source>Language Packages</source>
        <translation>Pachete de limbă</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="52"/>
        <source>Detection and installation of language packages</source>
        <translation>Detectarea și instalarea pachetelor de limbă</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="107"/>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="109"/>
        <source>%1 language packages</source>
        <translation>%1 pachete de limbă</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="160"/>
        <source>Global language packages</source>
        <translation>Pachete globale de limbă</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="182"/>
        <source>System is out-of-date</source>
        <translation>Sistemul este învechit</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="183"/>
        <source>Your System is not up-to-date! You have to update it first to continue!</source>
        <translation>Sistemul tău nu este la zi! Trebuie mai întai să îl actualizezi ca să poți continua!</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="215"/>
        <source>Install language packages.</source>
        <translation>Instalează pachete de limbă.</translation>
    </message>
</context>
<context>
    <name>LocaleCommon</name>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="33"/>
        <source>Locale Settings</source>
        <translation>Setări regionale</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="40"/>
        <source>Add and configure locales</source>
        <translation>Adaugă și configurează setările regionale</translation>
    </message>
</context>
<context>
    <name>LocaleModule</name>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="35"/>
        <source>Add</source>
        <translation>Adaugă</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="42"/>
        <source>Remove</source>
        <translation>Șterge</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="49"/>
        <source>Restore</source>
        <translation>Restaurează</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="62"/>
        <source>System Locales</source>
        <translation>Setările regionale ale sistemului</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="125"/>
        <source>Detailed Settings</source>
        <translation>Setări Detaliate</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="170"/>
        <source>Display Language</source>
        <translation>Afișează Limba</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="188"/>
        <source>Language:</source>
        <translation>Limba:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="198"/>
        <source>Collation and Sorting:</source>
        <translation>Asamblare și Sortare:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="208"/>
        <source>Messages:</source>
        <translation>Mesaje:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="218"/>
        <source>CType:</source>
        <translation>TipC:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="231"/>
        <source>Formats</source>
        <translation>Formate</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="249"/>
        <source>Numbers:</source>
        <translation>Numere:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="259"/>
        <source>Time:</source>
        <translation>Ora:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="269"/>
        <source>Currency:</source>
        <translation>Monedă:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="279"/>
        <source>Measurement Units:</source>
        <translation>Unități de măsură:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="289"/>
        <source>Address:</source>
        <translation>Adresă:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="299"/>
        <source>Names:</source>
        <translation>Nume:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="309"/>
        <source>Telephone:</source>
        <translation>Telefon:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="319"/>
        <source>Identification:</source>
        <translation>Identificare:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="329"/>
        <source>Paper:</source>
        <translation>Hârtie:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="363"/>
        <source>Set as default display language and format</source>
        <translation>Setează ca limba și formatul de afișare implicit</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="368"/>
        <source>Set as default display language</source>
        <translation>Setează ca limba de afișare implicită</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="373"/>
        <source>Set as default format</source>
        <translation>Setează ca format implicit</translation>
    </message>
</context>
<context>
    <name>MhwdCommon</name>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="39"/>
        <source>Hardware Configuration</source>
        <translation>Configurare Hardware</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="46"/>
        <source>Condres Hardware Detection graphical user interface</source>
        <translation>Interfața grafică de detectare hardware a sistemului Condres</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="83"/>
        <source>Unknown device name</source>
        <translation>Dispozitiv cu nume necunoscut</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="142"/>
        <source>Install configuration</source>
        <translation>Instalează și configurează</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="143"/>
        <source>MHWD will install the &apos;%1&apos; configuration</source>
        <translation>MHWD va instala configurația &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="165"/>
        <source>Install open-source graphic driver</source>
        <translation>Instalează driver-ul grafic open-source</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="166"/>
        <source>MHWD will autodetect your open-source graphic drivers and install it</source>
        <translation>MHWD va auto-detecta driver-ul grafic open-source și îl va instala</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="187"/>
        <source>Install proprietary graphic driver</source>
        <translation>Instalează driver-ul grafic particular</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="188"/>
        <source>MHWD will autodetect your proprietary graphic drivers and install it</source>
        <translation>MHWD va auto-detecta driver-ul grafic particular și îl va instala</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="209"/>
        <source>Reinstall configuration</source>
        <translation>Reinstalează configurația</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="210"/>
        <source>MHWD will reinstall the &apos;%1&apos; configuration</source>
        <translation>MHWD va reinstala configurația &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="232"/>
        <source>Remove configuration</source>
        <translation>Șterge configurația</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="233"/>
        <source>MHWD will remove the &apos;%1&apos; configuration</source>
        <translation>MHWD va șterge configurația &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>MsmCommon</name>
    <message>
        <location filename="../MsmCommon.cpp" line="26"/>
        <source>Please use &lt;a href=&apos;%1&apos;&gt;%1&lt;/a&gt; to report bugs.</source>
        <translation>Te rugăm să folosești &lt;a href=&apos;%1&apos;&gt;%1&lt;/a&gt; ca să raportezi erori.</translation>
    </message>
</context>
<context>
    <name>MsmWindow</name>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="14"/>
        <source>Condres Settings Manager</source>
        <translation>Managerul de Setări al lui Condres</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="185"/>
        <source>All Settings</source>
        <translation>Toate Setările</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="211"/>
        <location filename="../../msm/MsmWindow.ui" line="235"/>
        <source>Quit</source>
        <translation>Ieșire</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="224"/>
        <source>Apply</source>
        <translation>Aplică</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="44"/>
        <source>System</source>
        <translation>Sistem</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="50"/>
        <source>Hardware</source>
        <translation>Hardware</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="153"/>
        <source>Condres Settings</source>
        <translation>Setările lui Condres</translation>
    </message>
</context>
<context>
    <name>Notifier</name>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="47"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="47"/>
        <source>Kernels</source>
        <translation>Nuclee</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="51"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="51"/>
        <source>Language packages</source>
        <translation>Pachete de limbă</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="55"/>
        <source>Quit</source>
        <translation>Ieșire</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="59"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="56"/>
        <source>Options</source>
        <translation>Opțiuni</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="191"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="230"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="238"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="291"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="40"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="181"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="220"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="228"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="281"/>
        <source>Condres Settings Manager</source>
        <translation>Managerul de Setări al lui Condres</translation>
    </message>
    <message numerus="yes">
        <location filename="../../notifier/notifier/Notifier.cpp" line="192"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="182"/>
        <source>%n new additional language package(s) available</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="231"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="221"/>
        <source>Running an unsupported kernel, please update.</source>
        <translation>Rulezi un nucleu nesuportat, te rugăm să actualizezi sistemul.</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="239"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="229"/>
        <source>Unsupported kernel installed in your system, please remove it.</source>
        <translation>Un nucleu nesuportat a fost instalat în sistemul tău, te rugăm să îl ștergi.</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="292"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="282"/>
        <source>Newer kernel is available, please update.</source>
        <translation>Un nucleu mai nou este disponibil, te rugăm să actualizezi sistemul.</translation>
    </message>
</context>
<context>
    <name>NotifierSettingsDialog</name>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="20"/>
        <source>Kernel Notifications</source>
        <translation>Notificări de Nucleu</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="26"/>
        <source>Check unsupported kernels</source>
        <translation>Verifică nucleele nesuportate</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="51"/>
        <source>Only notify if running an unsupported kernel</source>
        <translation>Avertizează-mă doar când folosesc un nucleu nesuportat</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="60"/>
        <source>Check new kernels</source>
        <translation>Verifică noile nuclee</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="85"/>
        <source>Only notify LTS kernels</source>
        <translation>Avertizează-mă doar în legatură cu nucleele LTS</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="112"/>
        <source>Only notify recommended kernels</source>
        <translation>Avertizează-mă doar în legatură cu nucleele recomandate</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="124"/>
        <source>Language Packs Notifications</source>
        <translation>Notificări Pachete de Limbă</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="130"/>
        <source>Check missing language packs</source>
        <translation>Verifică pachetele de limbă care lipsesc</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="168"/>
        <source>Quit</source>
        <translation>Ieșire</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="181"/>
        <source>Apply</source>
        <translation>Aplică</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="32"/>
        <source>Notifications settings</source>
        <translation>Setări Notificări</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="107"/>
        <source>Format error when saving your notifications settings</source>
        <translation>Eroare de formatare la salvarea setărilor de notificare</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="111"/>
        <source>Access error when saving your notifications settings</source>
        <translation>Eroare de acces la salvarea setărilor de notificare</translation>
    </message>
</context>
<context>
    <name>PageKeyboard</name>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="25"/>
        <source>Keyboard Model:</source>
        <translation>Model tastatură:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="131"/>
        <source>Type here to test your keyboard</source>
        <translation>Tastați aici pentru a testa tastatura</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="140"/>
        <source>Delay:</source>
        <translation>Întârziere:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="158"/>
        <source>Delay</source>
        <translation>Întârziere</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="165"/>
        <source>Set delay</source>
        <translation>Setează întârzierea</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="183"/>
        <source>Rate:</source>
        <translation>Ritm:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="201"/>
        <source>Rate  </source>
        <translation>Ritm </translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="208"/>
        <source>Set Rate</source>
        <translation>Setează Ritmul</translation>
    </message>
</context>
<context>
    <name>PageLanguagePackages</name>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="24"/>
        <source>Available Language Packages</source>
        <translation>Pachete de limbă disponibile</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="32"/>
        <source>Additional language packages can be installed:</source>
        <translation>Pachete de limbă adiționale pot fi instalate:</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="55"/>
        <source>Install Packages</source>
        <translation>Instalează Pachetele</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="80"/>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="128"/>
        <source>Package</source>
        <translation>Pachete</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="85"/>
        <source>Description</source>
        <translation>Descriere</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="133"/>
        <source>Parent Package</source>
        <translation>Pachet părinte</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="90"/>
        <source>Install</source>
        <translation>Instalează</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="99"/>
        <source>Installed Language Packages</source>
        <translation>Pachete de limbă instalate</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="105"/>
        <source>Installed language packages:</source>
        <translation>Pachete de limbă instalate:</translation>
    </message>
</context>
<context>
    <name>PageMhwd</name>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="37"/>
        <source>Auto Install
Open-source Driver</source>
        <translation>Autoinstalează
Driverul liber</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="45"/>
        <source>Auto Install
Proprietary Driver</source>
        <translation>Autoinstalează
Dirverul proprietar</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="67"/>
        <source>Driver</source>
        <translation>Driver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="72"/>
        <source>Open-source</source>
        <translation>Open-source</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="77"/>
        <source>Installed</source>
        <translation>Instalat</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="85"/>
        <source>Show all devices</source>
        <translation>Arată toate dispozitivele</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="104"/>
        <source>Reinstall</source>
        <translation>Reinstalează</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="94"/>
        <source>Install</source>
        <translation>Instalează</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="99"/>
        <source>Remove</source>
        <translation>Șterge</translation>
    </message>
</context>
<context>
    <name>PageTimeDate</name>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="20"/>
        <source>Time and Date</source>
        <translation>Oră și dată</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="26"/>
        <source>Set time and date automatically</source>
        <translation>Setează ora și data automat</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="148"/>
        <source>Time Zone</source>
        <translation>Fus orar</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="197"/>
        <source>Change Time Zone</source>
        <translation>Schimbă fusul orar</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="33"/>
        <source>Hardware clock in local time zone</source>
        <translation>Ceasul hardware în fusul orar local</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="51"/>
        <source>Time:</source>
        <translation>Oră:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="86"/>
        <source>Date:</source>
        <translation>Dată:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="115"/>
        <source>Hardware clock:</source>
        <translation>Ceas hardware:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="122"/>
        <source>Universal time:</source>
        <translation>Oră universală:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="165"/>
        <source>Time zone:</source>
        <translation>Fus orar:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="206"/>
        <source>Country:</source>
        <translation>Țară:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="246"/>
        <source>Has daylight time?</source>
        <translation>Are oră de vară?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="276"/>
        <source>Is daylight time?</source>
        <translation>Este oră de vară?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="306"/>
        <source>Has transitions?</source>
        <translation>Are tranziții?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="317"/>
        <source>Next transition:</source>
        <translation>Următoarea tranziție:</translation>
    </message>
</context>
<context>
    <name>PageUsers</name>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="154"/>
        <source>Image</source>
        <translation>Imagine</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="161"/>
        <source>Username</source>
        <translation>Utilizator</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="168"/>
        <source>Account Type</source>
        <translation>Tip cont</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="175"/>
        <source>Password</source>
        <translation>Parolă</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="223"/>
        <source>●●●●●●</source>
        <translation>●●●●●●</translation>
    </message>
</context>
<context>
    <name>PreviewFileDialog</name>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="93"/>
        <source>Width:</source>
        <translation>Lățime:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="94"/>
        <source>Height:</source>
        <translation>Înălțime:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="95"/>
        <source>Ratio:</source>
        <translation>Rație:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="96"/>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="97"/>
        <source>%1 px</source>
        <translation>%1 px</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="98"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
</context>
<context>
    <name>SelectLocalesDialog</name>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="14"/>
        <source>Add Locale</source>
        <translation>Adaugă localizare</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="34"/>
        <source>Language</source>
        <translation>Limbă</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="70"/>
        <source>Territory</source>
        <translation>Teritoriu</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="122"/>
        <source>Locale:</source>
        <translation>Localizare:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="182"/>
        <source>Cancel</source>
        <translation>Renunță</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="189"/>
        <source>Add</source>
        <translation>Adaugă</translation>
    </message>
</context>
<context>
    <name>TimeDateCommon</name>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="38"/>
        <source>Time and Date</source>
        <translation>Ora și Data</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="45"/>
        <source>Time and date configuration</source>
        <translation>Configurarea orei și datei</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="138"/>
        <source>none</source>
        <translation>niciunul</translation>
    </message>
</context>
<context>
    <name>TimeZoneDialog</name>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="14"/>
        <source>Time Zone Selection</source>
        <translation>Selecție fus orar</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="25"/>
        <source>Region:</source>
        <translation>Regiune:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="61"/>
        <source>Zone:</source>
        <translation>Zonă:</translation>
    </message>
</context>
<context>
    <name>UsersCommon</name>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="47"/>
        <source>User Accounts</source>
        <translation>Conturi Utilizatori</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="54"/>
        <source>User accounts configuration</source>
        <translation>Configurarea conturi de utilizator</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="135"/>
        <source>Continue?</source>
        <translation>Continuii?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="136"/>
        <source>Do you really want to remove the user %1?</source>
        <translation>Chiar dorești să ștergi utilizatorul %1?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="143"/>
        <source>Remove Home?</source>
        <translation>Șterge Home?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="144"/>
        <source>Do you want to remove the home folder of the user %1?</source>
        <translation>Dorești să ștergi directorul home pentru utilizatorul %1?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="166"/>
        <location filename="../../modules/users/UsersCommon.cpp" line="236"/>
        <source>Error!</source>
        <translation>Eroare!</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="167"/>
        <source>Failed to remove user %1</source>
        <translation>Nu am reușit să șterg utilizatorul %1</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="183"/>
        <source>Images (*.png *.jpg *.bmp)</source>
        <translation>Imagini (*.png *.jpg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="237"/>
        <source>Failed to change user image</source>
        <translation>Nu am reușit să înlocuiesc imaginea utilizatorului</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="248"/>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="267"/>
        <source>Administrator</source>
        <translation>Administrator</translation>
    </message>
</context>
</TS>
