#if defined(DUMMYOS)
	#include "dazukoio_dummyos.h"
#else
	#include "dazukoio_unix.h"
#endif
