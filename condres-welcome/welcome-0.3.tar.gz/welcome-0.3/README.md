![screenshot](https://raw.github.com/jkw/condres-welcome/master/screenshot.png)

condres-welcome
================

condres welcome screen

* python3
* gtk
* python-simplejson
* python-gobject
* python-pydbus
