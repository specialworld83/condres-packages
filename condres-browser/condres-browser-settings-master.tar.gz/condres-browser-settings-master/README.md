# condres-browser-settings
Condres distribution defaults for
- Firefox / Palemoon
- Google-Chrome / Chromium
