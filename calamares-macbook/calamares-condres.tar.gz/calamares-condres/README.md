# calamares-configs
The condres modules and config files for the calamares installer framework
