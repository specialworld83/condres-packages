# [Antergos Architect Installer](https://github.com/antergos/architect)

CLI Installer for Antergos

Based on the [Architect Installation Framework](https://github.com/Acidburn0zzz/aif-dev)
