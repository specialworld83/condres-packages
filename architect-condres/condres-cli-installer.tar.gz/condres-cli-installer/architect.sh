# !/bin/bash
#
# Condres OS  Architect Installation Framework
#
# Original work by Carl Duff for Architect Linux v2.2.1 (2016)
# Modified for Condres OS  by Karasu (karasu@Condres OS .com) (2017)
#
# This program is free software, provided under the GNU General Public License
# as published by the Free Software Foundation. So feel free to copy, distribute,
# or modify it as you wish.

######################################################################
##                                                                  ##
##                   Installer Variables                            ##
##                                                                  ##
######################################################################

SCRIPT_DIR="/usr/share/condres-architect"
TRANSDIR="${SCRIPT_DIR}/trans"
LIBDIR="${SCRIPT_DIR}/lib"

# Temporary files to store menu selections
ANSWER="/tmp/.aif"              # Basic menu selections
PACKAGES="/tmp/.pkgs"           # Packages to install
BTRFS_OPTS="/tmp/.btrfs_opts"   # BTRFS mount options

# Condres OS  Architect Installation Framework version
VERSION="1.0.1"

# Installation
DM_INST=""                          # Which DMs have been installed?
DM_ENABLED=0                        # Has a display manager been enabled?
NM_INST=""                          # Which NMs have been installed?
NM_ENABLED=0                        # Has a network connection manager been enabled?
KEYMAP="us"                         # Virtual console keymap. Default is "us"
XKBMAP="us"                         # X11 keyboard layout. Default is "us"
ZONE=""                             # For time
SUBZONE=""                          # For time
LOCALE="en_US.UTF-8"                # System locale. Default is "en_US.UTF-8"
KERNEL="n"                          # Kernel(s) installed (base install); kernels for mkinitcpio
GRAPHIC_CARD=""                     # graphics card
INTEGRATED_GC=""                    # Integrated graphics card for NVIDIA
NVIDIA_INST=0                       # Indicates if NVIDIA proprietary driver has been installed
NVIDIA=""                           # NVIDIA driver(s) to install depending on kernel(s)
VB_MOD=""                           # Virtualbox guest modules to install depending on kernel(s)
SHOW_ONCE=0                         # Show de_wm information only once
MOUNTPOINT="/mnt"                   # Installation: Root mount
MOUNT=""                            # Installation: All other mounts branching from Root
BTRFS=0                             # BTRFS used? "1" = btrfs alone, "2" = btrfs + subvolume(s)
BTRFS_MNT=""                        # used for syslinux where /mnt is a btrfs subvolume
F2FS=0                              # F2FS used? "1" = yes.
INCLUDE_PART='part\|lvm\|crypt'     # Partition types to include for display and selection.
COPY_PACCONF=0                      # Copy over installer /etc/pacman.conf to installed system?

# Architecture
ARCHI=`uname -m`                    # Display whether 32 or 64 bit system
SYSTEM="Unknown"                    # Display whether system is BIOS or UEFI. Default is "unknown"
ROOT_PART=""                        # ROOT partition
UEFI_PART=""                        # UEFI partition
UEFI_MOUNT=""                       # UEFI mountpoint

# Menu highlighting (automated step progression)
HIGHLIGHT=0                         # Highlight items for Main Menu
HIGHLIGHT_SUB=0                     # Highlight items for submenus
SUB_MENU=""                         # Submenu to be highlighted

# Logical Volume Management
LVM=0                               # Logical Volume Management Detected?
LVM_SEP_BOOT=0                      # 1 = Seperate /boot, 2 = seperate /boot & LVM
LVM_VG=""                           # Name of volume group to create or use
LVM_VG_MB=0                         # MB remaining of VG
LVM_LV_NAME=""                      # Name of LV to create or use
LV_SIZE_INVALID=0                   # Is LVM LV size entered valid?
VG_SIZE_TYPE=""                     # Is VG in Gigabytes or Megabytes?

# LUKS
LUKS=0                              # Luks Detected?
LUKS_DEV=""                         # If encrypted, partition
LUKS_NAME=""                        # Name given to encrypted partition
LUKS_UUID=""                        # UUID used for comparison purposes
LUKS_OPT=""                         # Default or user-defined?

# Language Support
CURR_LOCALE="en_US.UTF-8"           # Default Locale
FONT="ter-v14b"                     # Set new font if necessary

# Edit Files
FILE=""                             # File(s) to be reviewed

# Offline Installation
AIROOTIMG=""                        # Root image to install
BYPASS="$MOUNTPOINT/bypass/"        # Root image mountpoint

# Available desktops
DESKTOPS=( "base")

PROFILES="/tmp/profiles"            # Where to store package lists

# XML with all package lists
XML_URL="https://condresos.codelinsoft.it/packages.xml"
XML_TMP="/tmp/.packages.xml"

# Save retyping
BACK_TITLE="Condres OS  Architect Installation Framework $VERSION"

export DIALOGRC="${SCRIPT_DIR}/dialogrc"   # DIALOG config File

source ${TRANSDIR}/english.trans

[[ -r ${LIBDIR}/aa-core.sh ]] && source ${LIBDIR}/aa-core.sh

import ${LIBDIR}/aa-bootloader.sh
import ${LIBDIR}/aa-filesystem.sh
import ${LIBDIR}/aa-install.sh
import ${LIBDIR}/aa-luks.sh
import ${LIBDIR}/aa-lvm.sh
import ${LIBDIR}/aa-mirrors.sh
import ${LIBDIR}/aa-packages.sh
import ${LIBDIR}/aa-system.sh


######################################################################
##                                                                  ##
##                 Main Interfaces                                  ##
##                                                                  ##
######################################################################

# Greet the user when first starting the installer
greeting() {
    DIALOG " $_WelTitle $VERSION " --msgbox "$_WelBody" 0 0
}

# Preparation
prep_menu() {
    if [[ $SUB_MENU != "prep_menu" ]]; then
        SUB_MENU="prep_menu"
        HIGHLIGHT_SUB=1
    else
        if [[ $HIGHLIGHT_SUB != 7 ]]; then
            HIGHLIGHT_SUB=$(( HIGHLIGHT_SUB + 1 ))
        fi
    fi

    dialog --default-item ${HIGHLIGHT_SUB} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_PrepMenuTitle " --menu "$_PrepMenuBody" 0 0 7 \
    "1" "$_VCKeymapTitle" \
    "2" "$_DevShowOpt" \
    "3" "$_PrepPartDisk" \
    "4" "$_PrepLUKS" \
    "5" "$_PrepLVM $_PrepLVM2" \
    "6" "$_PrepMntPart" \
    "7" "$_Back" 2>${ANSWER}

    HIGHLIGHT_SUB=$(cat ${ANSWER})
    case $(cat ${ANSWER}) in
        "1") set_keymap
        ;;
        "2") show_devices
        ;;
        "3") umount_partitions
            select_device
            create_partitions
        ;;
        "4") luks_menu
        ;;
        "5") lvm_menu
        ;;
        "6") mount_partitions
        ;;
        *) main_menu_online
        ;;
    esac

    prep_menu
}

# Base Installation
install_base_menu() {
    if [[ $SUB_MENU != "install_base_menu" ]]; then
        SUB_MENU="install_base_menu"
        HIGHLIGHT_SUB=1
    else
        if [[ $HIGHLIGHT_SUB != 5 ]]; then
            HIGHLIGHT_SUB=$(( HIGHLIGHT_SUB + 1 ))
        fi
    fi

    dialog --default-item ${HIGHLIGHT_SUB} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_InstBsMenuTitle " --menu "$_InstBseMenuBody" 0 0 5 \
    "1" "$_PrepMirror" \
    "2" "$_PrepPacKey" \
    "3" "$_InstBse" \
    "4" "$_InstBseOffline" \
    "5" "$_InstBootldr" \
    "6" "$_Back" 2>${ANSWER}

    HIGHLIGHT_SUB=$(cat ${ANSWER})
    case $(cat ${ANSWER}) in
        "1") configure_mirrorlist
        ;;
        "2") clear
            pacman-key --init
            pacman-key --populate archlinux
            pacman-key --populate condres
            pacman-key --refresh-keys
        ;;
        "3") install_base
        ;;
        "4") install_base_offline
        ;;
        "5") install_bootloader
        ;;
        *) main_menu_online
        ;;
    esac

    install_base_menu
}

# Base Configuration
config_base_menu() {
    # Set the default PATH variable
    arch_chroot "PATH=/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/bin/core_perl" 2>/tmp/.errlog
    check_for_error

    if [[ $SUB_MENU != "config_base_menu" ]]; then
        SUB_MENU="config_base_menu"
        HIGHLIGHT_SUB=1
    else
        if [[ $HIGHLIGHT_SUB != 8 ]]; then
            HIGHLIGHT_SUB=$(( HIGHLIGHT_SUB + 1 ))
        fi
    fi

    dialog --default-item ${HIGHLIGHT_SUB} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_ConfBseMenuTitle " --menu "$_ConfBseBody" 0 0 8 \
    "1" "$_ConfBseFstab" \
    "2" "$_ConfBseHost" \
    "3" "$_ConfBseSysLoc" \
    "4" "$_ConfBseTimeHC" \
    "5" "$_ConfUsrRoot" \
    "6" "$_ConfUsrNew" \
    "7" "$_MMRunMkinit" \
    "8" "$_Back" 2>${ANSWER}

    HIGHLIGHT_SUB=$(cat ${ANSWER})
    case $(cat ${ANSWER}) in
        "1") generate_fstab
        ;;
        "2") set_hostname
        ;;
        "3") set_locale
        ;;
        "4") set_timezone
            set_hw_clock
        ;;
        "5") set_root_password
        ;;
        "6") create_new_user
        ;;
        "7") run_mkinitcpio
        ;;
        *) main_menu_online
        ;;
    esac

    config_base_menu
}

install_graphics_menu() {
    if [[ $SUB_MENU != "install_graphics_menu" ]]; then
        SUB_MENU="install_graphics_menu"
        HIGHLIGHT_SUB=1
    else
        if [[ $HIGHLIGHT_SUB != 6 ]]; then
            HIGHLIGHT_SUB=$(( HIGHLIGHT_SUB + 1 ))
        fi
    fi

    dialog --default-item ${HIGHLIGHT_SUB} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_InstGrMenuTitle " --menu "$_InstGrMenuBody" 0 0 6 \
    "1" "$_InstGrMenuDS" \
    "2" "$_InstGrMenuDD" \
    "3" "$_InstGrMenuGE" \
    "4" "$_InstGrMenuDM" \
    "5" "$_PrepKBLayout" \
    "6" "$_Back" 2>${ANSWER}

    HIGHLIGHT_SUB=$(cat ${ANSWER})
    case $(cat ${ANSWER}) in
        "1") install_xorg_input
        ;;
        "2") setup_graphics_card
        ;;
        "3") install_de_wm
        ;;
        "4") install_dm
        ;;
        "5") set_xkbmap
        ;;
        *) main_menu_online
        ;;
    esac

    install_graphics_menu
}

# Install Accessibility Applications
install_acc_menu() {
    echo "" > ${PACKAGES}

    DIALOG " $_InstAccTitle " --checklist "$_InstAccBody" 0 0 15 \
    "accerciser" "-" off \
    "at-spi2-atk" "-" off \
    "at-spi2-core" "-" off \
    "brltty" "-" off \
    "caribou" "-" off \
    "dasher" "-" off \
    "espeak" "-" off \
    "espeakup" "-" off \
    "festival" "-" off \
    "java-access-bridge" "-" off \
    "java-atk-wrapper" "-" off \
    "julius" "-" off \
    "orca" "-" off \
    "qt-at-spi" "-" off \
    "speech-dispatcher" "-" off 2>${PACKAGES}

    clear

    # If something has been selected, install
    if [[ $(cat ${PACKAGES}) != "" ]]; then
        pacstrap ${MOUNTPOINT} ${PACKAGES} 2>/tmp/.errlog
        check_for_error
    fi

    install_multimedia_menu
}

edit_configs() {
    # Clear the file variables
    FILE=""
    user_list=""

    if [[ $SUB_MENU != "edit configs" ]]; then
        SUB_MENU="edit configs"
        HIGHLIGHT_SUB=1
    else
        if [[ $HIGHLIGHT_SUB != 12 ]]; then
            HIGHLIGHT_SUB=$(( HIGHLIGHT_SUB + 1 ))
        fi
    fi

    dialog --default-item ${HIGHLIGHT_SUB} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_SeeConfOptTitle " --menu "$_SeeConfOptBody" 0 0 12 \
    "1" "/etc/vconsole.conf" \
    "2" "/etc/locale.conf" \
    "3" "/etc/hostname" \
    "4" "/etc/hosts" \
    "5" "/etc/sudoers" \
    "6" "/etc/mkinitcpio.conf" \
    "7" "/etc/fstab" \
    "8" "/etc/crypttab" \
    "9" "grub/syslinux/systemd-boot" \
    "10" "lxdm/lightdm/sddm" \
    "11" "/etc/pacman.conf" \
    "12" "$_Back" 2>${ANSWER}

    HIGHLIGHT_SUB=$(cat ${ANSWER})
    case $(cat ${ANSWER}) in
        "1") [[ -e ${MOUNTPOINT}/etc/vconsole.conf ]] && FILE="${MOUNTPOINT}/etc/vconsole.conf"
        ;;
        "2") [[ -e ${MOUNTPOINT}/etc/locale.conf ]] && FILE="${MOUNTPOINT}/etc/locale.conf"
        ;;
        "3") [[ -e ${MOUNTPOINT}/etc/hostname ]] && FILE="${MOUNTPOINT}/etc/hostname"
        ;;
        "4") [[ -e ${MOUNTPOINT}/etc/hosts ]] && FILE="${MOUNTPOINT}/etc/hosts"
        ;;
        "5") [[ -e ${MOUNTPOINT}/etc/sudoers ]] && FILE="${MOUNTPOINT}/etc/sudoers"
        ;;
        "6") [[ -e ${MOUNTPOINT}/etc/mkinitcpio.conf ]] && FILE="${MOUNTPOINT}/etc/mkinitcpio.conf"
        ;;
        "7") [[ -e ${MOUNTPOINT}/etc/fstab ]] && FILE="${MOUNTPOINT}/etc/fstab"
        ;;
        "8") [[ -e ${MOUNTPOINT}/etc/crypttab ]] && FILE="${MOUNTPOINT}/etc/crypttab"
        ;;
        "9") [[ -e ${MOUNTPOINT}/etc/default/grub ]] && FILE="${MOUNTPOINT}/etc/default/grub"
            [[ -e ${MOUNTPOINT}/boot/syslinux/syslinux.cfg ]] && FILE="$FILE ${MOUNTPOINT}/boot/syslinux/syslinux.cfg"
            if [[ -e ${MOUNTPOINT}${UEFI_MOUNT}/loader/loader.conf ]]; then
                files=$(ls ${MOUNTPOINT}${UEFI_MOUNT}/loader/entries/*.conf)
                for i in ${files}; do
                    FILE="$FILE ${i}"
                done
            fi
        ;;
        "10") [[ -e ${MOUNTPOINT}/etc/lxdm/lxdm.conf ]] && FILE="${MOUNTPOINT}/etc/lxdm/lxdm.conf"
            [[ -e ${MOUNTPOINT}/etc/lightdm/lightdm.conf ]] && FILE="${MOUNTPOINT}/etc/lightdm/lightdm.conf"
            [[ -e ${MOUNTPOINT}/etc/sddm.conf ]] && FILE="${MOUNTPOINT}/etc/sddm.conf"
        ;;
        "11") [[ -e ${MOUNTPOINT}/etc/pacman.conf ]] && FILE="${MOUNTPOINT}/etc/pacman.conf"
        ;;
        *) main_menu_online
        ;;
    esac

    [[ $FILE != "" ]] && nano $FILE \
    || DIALOG " $_ErrTitle " --msgbox "$_SeeConfErrBody1" 0 0

    edit_configs
}

main_menu_online() {
    if [[ $HIGHLIGHT != 9 ]]; then
        HIGHLIGHT=$(( HIGHLIGHT + 1 ))
    fi

    dialog --default-item ${HIGHLIGHT} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_MMTitle " \
    --menu "$_MMBody" 0 0 9 \
    "1" "$_PrepMenuTitle" \
    "2" "$_InstBsMenuTitle" \
    "3" "$_ConfBseMenuTitle" \
    "4" "$_InstGrMenuTitle" \
    "5" "$_InstNMMenuTitle" \
    "6" "$_InstMultMenuTitle" \
    "7" "$_SecMenuTitle" \
    "8" "$_SeeConfOptTitle" \
    "9" "$_Done" 2>${ANSWER}

    HIGHLIGHT=$(cat ${ANSWER})

    # Depending on the answer, first check whether partition(s) are mounted and whether base has been installed
    if [[ $(cat ${ANSWER}) -eq 2 ]]; then
        check_mount
    fi

    if [[ $(cat ${ANSWER}) -ge 3 ]] && [[ $(cat ${ANSWER}) -le 8 ]]; then
        check_mount
        check_base
    fi

    case $(cat ${ANSWER}) in
        "1") prep_menu
        ;;
        "2") install_base_menu
        ;;
        "3") config_base_menu
        ;;
        "4") install_graphics_menu
        ;;
        "5") install_network_menu
        ;;
        "6") install_multimedia_menu
        ;;
        "7") security_menu
        ;;
        "8") edit_configs
        ;;
        *) dialog --backtitle "$VERSION - $SYSTEM ($ARCHI)" --yesno "$_CloseInstBody" 0 0

            if [[ $? -eq 0 ]]; then
                umount_partitions
                clear
                exit 0
            else
                main_menu_online
            fi
        ;;
    esac

    main_menu_online
}

######################################################################
##                                                                  ##
##                        Execution                                 ##
##                                                                  ##
######################################################################

id_system
select_language
check_requirements
greeting

while true; do
    main_menu_online
done
