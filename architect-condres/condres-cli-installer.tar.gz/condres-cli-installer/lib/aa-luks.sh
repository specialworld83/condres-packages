# !/bin/bash
#
# Antergos Architect Installation Framework
#
# Original work by Carl Duff for Architect Linux v2.2.1 (2016)
# Modified for Antergos by Karasu (karasu@antergos.com) (2017)
#
# This program is free software, provided under the GNU General Public License
# as published by the Free Software Foundation. So feel free to copy, distribute,
# or modify it as you wish.

######################################################################
##                                                                  ##
##             Encryption (dm_crypt) Functions                      ##
##                                                                  ##
######################################################################

# Had to write it in this way due to (bash?) bug(?), as if/then statements in a single
# "create LUKS" function for default and "advanced" modes were interpreted as commands,
# not mere string statements. Not happy with it, but it works...

# Save repetition of code.
luks_password(){
    DIALOG " $_PrepLUKS " --clear --insecure --passwordbox "$_LuksPassBody" 0 0 2> ${ANSWER} || prep_menu
    PASSWD=$(cat ${ANSWER})

    DIALOG " $_PrepLUKS " --clear --insecure --passwordbox "$_PassReEntBody" 0 0 2> ${ANSWER} || prep_menu
    PASSWD2=$(cat ${ANSWER})

    if [[ $PASSWD != $PASSWD2 ]]; then
        DIALOG " $_ErrTitle " --msgbox "$_PassErrBody" 0 0
        luks_password
    fi
}

luks_open(){
    LUKS_ROOT_NAME=""
    INCLUDE_PART='part\|crypt\|lvm'
    umount_partitions
    find_partitions

    # Select encrypted partition to open
    DIALOG " $_LuksOpen " --menu "$_LuksMenuBody" 0 0 7 ${PARTITIONS} 2>${ANSWER} || luks_menu
    PARTITION=$(cat ${ANSWER})

    # Enter name of the Luks partition and get password to open it
    DIALOG " $_LuksOpen " --inputbox "$_LuksOpenBody" 10 50 "cryptroot" 2>${ANSWER} || luks_menu
    LUKS_ROOT_NAME=$(cat ${ANSWER})
    luks_password

    # Try to open the luks partition with the credentials given. If successful show this, otherwise
    # show the error
    DIALOG " $_LuksOpen " --infobox "$_PlsWaitBody" 0 0
    echo $PASSWD | cryptsetup open --type luks ${PARTITION} ${LUKS_ROOT_NAME} 2>/tmp/.errlog
    check_for_error

    lsblk -o NAME,TYPE,FSTYPE,SIZE,MOUNTPOINT ${PARTITION} | grep "crypt\|NAME\|MODEL\|TYPE\|FSTYPE\|SIZE" > /tmp/.devlist
    DIALOG " $_DevShowOpt " --textbox /tmp/.devlist 0 0

    luks_menu
}

luks_setup(){
    modprobe -a dm-mod dm_crypt
    INCLUDE_PART='part\|lvm'
    umount_partitions
    find_partitions

    # Select partition to encrypt
    DIALOG " $_LuksEncrypt " --menu "$_LuksCreateBody" 0 0 7 ${PARTITIONS} 2>${ANSWER} || luks_menu
    PARTITION=$(cat ${ANSWER})

    # Enter name of the Luks partition and get password to create it
    DIALOG " $_LuksEncrypt " --inputbox "$_LuksOpenBody" 10 50 "cryptroot" 2>${ANSWER} || luks_menu
    LUKS_ROOT_NAME=$(cat ${ANSWER})
    luks_password
}

luks_default() {
    # Encrypt selected partition or LV with credentials given
    DIALOG " $_LuksEncrypt " --infobox "$_PlsWaitBody" 0 0
    sleep 2
    echo $PASSWD | cryptsetup -q luksFormat ${PARTITION} 2>/tmp/.errlog

    # Now open the encrypted partition or LV
    echo $PASSWD | cryptsetup open ${PARTITION} ${LUKS_ROOT_NAME} 2>/tmp/.errlog
    check_for_error
}

luks_key_define() {
    DIALOG " $_PrepLUKS " --inputbox "$_LuksCipherKey" 0 0 "-s 512 -c aes-xts-plain64" 2>${ANSWER} || luks_menu

    # Encrypt selected partition or LV with credentials given
    DIALOG " $_LuksEncryptAdv " --infobox "$_PlsWaitBody" 0 0
    sleep 2

    echo $PASSWD | cryptsetup -q $(cat ${ANSWER}) luksFormat ${PARTITION} 2>/tmp/.errlog
    check_for_error

    # Now open the encrypted partition or LV
    echo $PASSWD | cryptsetup open ${PARTITION} ${LUKS_ROOT_NAME} 2>/tmp/.errlog
    check_for_error
}

luks_show(){
    echo -e ${_LuksEncruptSucc} > /tmp/.devlist
    lsblk -o NAME,TYPE,FSTYPE,SIZE ${PARTITION} | grep "part\|crypt\|NAME\|TYPE\|FSTYPE\|SIZE" >> /tmp/.devlist
    DIALOG " $_LuksEncrypt " --textbox /tmp/.devlist 0 0

    luks_menu
}

luks_menu() {
    LUKS_OPT=""

    DIALOG " $_PrepLUKS " --menu "$_LuksMenuBody$_LuksMenuBody2$_LuksMenuBody3" 0 0 4 \
    "$_LuksOpen" "cryptsetup open --type luks" \
    "$_LuksEncrypt" "cryptsetup -q luksFormat" \
    "$_LuksEncryptAdv" "cryptsetup -q -s -c luksFormat" \
    "$_Back" "-" 2>${ANSWER}

    case $(cat ${ANSWER}) in
        "$_LuksOpen")   luks_open
        ;;
        "$_LuksEncrypt")    luks_setup
            luks_default
            luks_show
        ;;
        "$_LuksEncryptAdv") luks_setup
            luks_key_define
            luks_show
        ;;
        *)  prep_menu
        ;;
    esac

    luks_menu
}
