# !/bin/bash
#
# Antergos Architect Installation Framework
#
# Original work by Carl Duff for Architect Linux v2.2.1 (2016)
# Modified for Antergos by Karasu (karasu@antergos.com) (2017)
#
# This program is free software, provided under the GNU General Public License
# as published by the Free Software Foundation. So feel free to copy, distribute,
# or modify it as you wish.

######################################################################
##                                                                  ##
##                    Installation Functions                        ##
##                                                                  ##
######################################################################

# The linux kernel package will be removed from the base group as it and/or the lts version will be
# selected by the user. Two installation methods are available: Standard (group package based) and
# Advanced (individual package based). Neither will allow progress without selecting a kernel.
install_base() {
    # Prep variables
    echo "" > ${PACKAGES}
    echo "" > ${ANSWER}
    BTRF_CHECK=""
    F2FS_CHECK=""
    KERNEL="n"
    kernels="linux-lts linux-grsec linux-zen"

    # User to select "standard" or "advanced" installation Method
    DIALOG " $_InstBseTitle " --menu "$_InstBseBody" 0 0 2 \
    "1" "$_InstStandBase" \
    "2" "$_InstAdvBase" 2>${ANSWER}

    # "Standard" installation method
    if [[ $(cat ${ANSWER}) -eq 1 ]]; then
        DIALOG " $_InstBseTitle " --checklist "$_InstStandBseBody$_UseSpaceBar" 0 0 3 \
        "linux" "-" on \
        "linux-lts" "-" off \
        "base-devel" "-" on 2>${PACKAGES}
        # "Advanced" installation method
    elif [[ $(cat ${ANSWER}) -eq 2 ]]; then
        # Ask user to wait while package descriptions are gathered (because it takes ages)
        #DIALOG " $_InstAdvBase " --infobox "$_InstAdvWait $_PlsWaitBody" 0 0

        # Generate a package list with descriptions.
        PKG_LIST=""
        pkg_list=$(pacman -Sqg base base-devel | sed s/linux// | sed s/util-/util-linux/ | uniq | sort -u)

        # Add btrfs and f2fs packages to list and check if used
        BTRF_CHECK=$(echo "btrfs-progs" "-" off)
        F2FS_CHECK=$(echo "f2fs-tools" "-" off)
        [[ $(lsblk -lno FSTYPE | grep btrfs) != "" ]] && BTRF_CHECK=$(echo $BTRFS_CHECK | sed "s/ off/ on/g")
        [[ $(lsblk -lno FSTYPE | grep f2fs) != "" ]] && F2FS_CHECK=$(echo $F2FS_CHECK | sed "s/ off/ on/g")

        # Gather package descriptions for base group
        for i in ${pkg_list}; do
            PKG_LIST="${PKG_LIST} ${i} - on"
        done

        DIALOG " $_InstBseTitle " --checklist "$_InstAdvBseBody $_UseSpaceBar" 0 0 20 \
        "linux" "-" on \
        "linux-lts" "-" off \
        "linux-grsec" "-" off \
        "linux-zen" "-" off \
        $PKG_LIST $BTRF_CHECK $F2FS_CHECK 2>${PACKAGES}
    fi

    # If a selection made, act
    if [[ $(cat ${PACKAGES}) != "" ]]; then
        # Check to see if a kernel is already installed
        ls ${MOUNTPOINT}/boot/*.img >/dev/null 2>&1
        if [[ $? == 0 ]]; then
            KERNEL="y"
            # If not, check to see if the linux kernel has been selected
        elif [[ $(cat ${PACKAGES} | awk '{print $1}') == "linux" ]]; then
            KERNEL="y"
            # If no linux kernel, check to see if any of the others have been selected
        else
            for i in ${kernels}; do
                [[ $(cat ${PACKAGES} | grep ${i}) != "" ]] && KERNEL="y" && break;
            done
        fi

        # If no kernel selected, warn and restart
        if [[ $KERNEL == "n" ]]; then
            DIALOG " $_ErrTitle " --msgbox "$_ErrNoKernel" 0 0
            install_base

            # If at least one kernel selected, proceed with installation.
        elif [[ $KERNEL == "y" ]]; then
            clear
            [[ $(cat ${ANSWER}) -eq 1 ]] && pacstrap ${MOUNTPOINT} $(pacman -Sqg base | sed 's/linux//' | sed 's/util-/util-linux/') $(cat ${PACKAGES}) btrfs-progs f2fs-tools sudo 2>/tmp/.errlog
            [[ $(cat ${ANSWER}) -eq 2 ]] && pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog
            check_for_error

            # If the virtual console has been set, then copy config file to installation
            [[ -e /tmp/vconsole.conf ]] && cp -f /tmp/vconsole.conf ${MOUNTPOINT}/etc/vconsole.conf 2>/tmp/.errlog
            # If specified, copy over the pacman.conf file to the installation
            [[ $COPY_PACCONF -eq 1 ]] && cp -f /etc/pacman.conf ${MOUNTPOINT}/etc/pacman.conf 2>>/tmp/.errlog
            check_for_error
        fi
    fi
}

install_network_menu() {

    # ntp not exactly wireless, but this menu is the best fit.
    install_wireless_packages(){

        WIRELESS_PACKAGES=""
        wireless_pkgs="dialog iw rp-pppoe wireless_tools wpa_actiond"

        for i in ${wireless_pkgs}; do
            WIRELESS_PACKAGES="${WIRELESS_PACKAGES} ${i} - on"
        done
        # If no wireless, uncheck wireless pkgs
        [[ $(lspci | grep -i "Network Controller") == "" ]] && WIRELESS_PACKAGES=$(echo $WIRELESS_PACKAGES | sed "s/ on/ off/g")

        DIALOG " $_InstNMMenuPkg " --checklist "$_InstNMMenuPkgBody\n\n$_UseSpaceBar" 0 0 13 \
        $WIRELESS_PACKAGES \
        "ufw" "-" off \
        "gufw" "-" off \
        "ntp" "-" off \
        "b43-fwcutter" "Broadcom 802.11b/g/n" off \
        "bluez-firmware" "Broadcom BCM203x / STLC2300 Bluetooth" off \
        "ipw2100-fw" "Intel PRO/Wireless 2100" off \
        "ipw2200-fw" "Intel PRO/Wireless 2200" off \
        "zd1211-firmware" "ZyDAS ZD1211(b) 802.11a/b/g USB WLAN" off 2>${PACKAGES}

        if [[ $(cat ${PACKAGES}) != "" ]]; then
            clear
            pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog
            check_for_error
        fi
    }

    install_cups(){
        DIALOG " $_InstNMMenuCups " --checklist "$_InstCupsBody\n\n$_UseSpaceBar" 0 0 11 \
        "cups" "-" on \
        "cups-pdf" "-" off \
        "ghostscript" "-" on \
        "gsfonts" "-" on \
        "samba" "-" off 2>${PACKAGES}

        if [[ $(cat ${PACKAGES}) != "" ]]; then
            clear
            pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog
            check_for_error

            if [[ $(cat ${PACKAGES} | grep "cups") != "" ]]; then
                DIALOG " $_InstNMMenuCups " --yesno "$_InstCupsQ" 0 0
                if [[ $? -eq 0 ]]; then
                    arch_chroot "systemctl enable org.cups.cupsd.service" 2>/tmp/.errlog
                    check_for_error
                    DIALOG " $_InstNMMenuCups " --infobox "\n$_Done!\n\n" 0 0
                    sleep 2
                fi
            fi
        fi
    }

    if [[ $SUB_MENU != "install_network_packages" ]]; then
        SUB_MENU="install_network_packages"
        HIGHLIGHT_SUB=1
    else
        if [[ $HIGHLIGHT_SUB != 5 ]]; then
            HIGHLIGHT_SUB=$(( HIGHLIGHT_SUB + 1 ))
        fi
    fi

    dialog --default-item ${HIGHLIGHT_SUB} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_InstNMMenuTitle " --menu "$_InstNMMenuBody" 0 0 5 \
    "1" "$_SeeWirelessDev" \
    "2" "$_InstNMMenuPkg" \
    "3" "$_InstNMMenuNM" \
    "4" "$_InstNMMenuCups" \
    "5" "$_Back" 2>${ANSWER}

    case $(cat ${ANSWER}) in
        "1") # Identify the Wireless Device
            lspci -k | grep -i -A 2 "network controller" > /tmp/.wireless
            if [[ $(cat /tmp/.wireless) != "" ]]; then
                DIALOG " $_WirelessShowTitle " --textbox /tmp/.wireless 0 0
            else
                DIALOG " $_WirelessShowTitle " --msgbox "$_WirelessErrBody" 7 30
            fi
        ;;
        "2") install_wireless_packages
        ;;
        "3") install_nm
        ;;
        "4") install_cups
        ;;
        *) main_menu_online
        ;;
    esac

    install_network_menu
}

# Install xorg and input drivers. Also copy the xkbmap configuration file created earlier to the installed system
install_xorg_input() {
    echo "" > ${PACKAGES}

    DIALOG " $_InstGrMenuDS " --checklist "$_InstGrMenuDSBody\n\n$_UseSpaceBar" 0 0 12 \
    "wayland" "-" off \
    "xorg-server" "-" on \
    "xorg-server-common" "-" off \
    "xorg-server-utils" "-" on \
    "xorg-xinit" "-" on \
    "xorg-server-xwayland" "-" off \
    "xf86-input-evdev" "-" off \
    "xf86-input-joystick" "-" off \
    "xf86-input-keyboard" "-" on \
    "xf86-input-libinput" "-" off \
    "xf86-input-mouse" "-" on \
    "xf86-input-synaptics" "-" on 2>${PACKAGES}

    clear
    # If at least one package, install.
    if [[ $(cat ${PACKAGES}) != "" ]]; then
        pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog
        check_for_error
    fi

    # now copy across .xinitrc for all user accounts
    user_list=$(ls ${MOUNTPOINT}/home/ | sed "s/lost+found//")
    for i in ${user_list[@]}; do
        cp -f ${MOUNTPOINT}/etc/X11/xinit/xinitrc ${MOUNTPOINT}/home/$i
        arch_chroot "chown -R ${i}:users /home/${i}"
    done

    install_graphics_menu
}

setup_graphics_card() {
    # Save repetition
    install_intel(){
        pacstrap ${MOUNTPOINT} xf86-video-intel libva-intel-driver intel-ucode 2>/tmp/.errlog
        sed -i 's/MODULES=""/MODULES="i915"/' ${MOUNTPOINT}/etc/mkinitcpio.conf

        # Intel microcode (Grub, Syslinux and systemd-boot).
        # Done as seperate if statements in case of multiple bootloaders.
        if [[ -e ${MOUNTPOINT}/boot/grub/grub.cfg ]]; then
            DIALOG " grub-mkconfig " --infobox "$_PlsWaitBody" 0 0
            sleep 1
            arch_chroot "grub-mkconfig -o /boot/grub/grub.cfg" 2>>/tmp/.errlog
        fi

        # Syslinux
        [[ -e ${MOUNTPOINT}/boot/syslinux/syslinux.cfg ]] && sed -i "s/INITRD /&..\/intel-ucode.img,/g" ${MOUNTPOINT}/boot/syslinux/syslinux.cfg

        # Systemd-boot
        if [[ -e ${MOUNTPOINT}${UEFI_MOUNT}/loader/loader.conf ]]; then
            update=$(ls ${MOUNTPOINT}${UEFI_MOUNT}/loader/entries/*.conf)
            for i in ${upgate}; do
                sed -i '/linux \//a initrd \/intel-ucode.img' ${i}
            done
        fi
    }

    # Save repetition
    install_ati(){
        pacstrap ${MOUNTPOINT} xf86-video-ati 2>/tmp/.errlog
        sed -i 's/MODULES=""/MODULES="radeon"/' ${MOUNTPOINT}/etc/mkinitcpio.conf
    }

    # Main menu. Correct option for graphics card should be automatically highlighted.
    NVIDIA=""
    VB_MOD=""
    GRAPHIC_CARD=""
    INTEGRATED_GC="N/A"
    GRAPHIC_CARD=$(lspci | grep -i "vga" | sed 's/.*://' | sed 's/(.*//' | sed 's/^[ \t]*//')

    # Highlight menu entry depending on GC detected. Extra work is needed for NVIDIA
    if [[ $(echo $GRAPHIC_CARD | grep -i "nvidia") != "" ]]; then
        # If NVIDIA, first need to know the integrated GC
        [[ $(lscpu | grep -i "intel\|lenovo") != "" ]] && INTEGRATED_GC="Intel" || INTEGRATED_GC="ATI"

        # Second, identity the NVIDIA card and driver / menu entry
        if [[ $(dmesg | grep -i 'chipset' | grep -i 'nvc\|nvd\|nve') != "" ]]; then
            HIGHLIGHT_SUB_GC=4
        elif [[ $(dmesg | grep -i 'chipset' | grep -i 'nva\|nv5\|nv8\|nv9'﻿) != "" ]]; then
            HIGHLIGHT_SUB_GC=5
        elif [[ $(dmesg | grep -i 'chipset' | grep -i 'nv4\|nv6') != "" ]]; then
            HIGHLIGHT_SUB_GC=6
        else
            HIGHLIGHT_SUB_GC=3
        fi
        # All non-NVIDIA cards / virtualisation
    elif [[ $(echo $GRAPHIC_CARD | grep -i 'intel\|lenovo') != "" ]]; then
        HIGHLIGHT_SUB_GC=2
    elif [[ $(echo $GRAPHIC_CARD | grep -i 'ati') != "" ]]; then
        HIGHLIGHT_SUB_GC=1
    elif [[ $(echo $GRAPHIC_CARD | grep -i 'via') != "" ]]; then
        HIGHLIGHT_SUB_GC=7
    elif [[ $(echo $GRAPHIC_CARD | grep -i 'virtualbox') != "" ]]; then
        HIGHLIGHT_SUB_GC=8
    elif [[ $(echo $GRAPHIC_CARD | grep -i 'vmware') != "" ]]; then
        HIGHLIGHT_SUB_GC=9
    else
        HIGHLIGHT_SUB_GC=10
    fi

    dialog --default-item ${HIGHLIGHT_SUB_GC} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_GCtitle " \
    --menu "$GRAPHIC_CARD\n" 0 0 10 \
    "1" $"xf86-video-ati" \
    "2" $"xf86-video-intel" \
    "3" $"xf86-video-nouveau (+ $INTEGRATED_GC)" \
    "4" $"Nvidia (+ $INTEGRATED_GC)" \
    "5" $"Nvidia-340xx (+ $INTEGRATED_GC)" \
    "6" $"Nvidia-304xx (+ $INTEGRATED_GC)" \
    "7" $"xf86-video-openchrome" \
    "8" $"virtualbox-guest-dkms" \
    "9" $"xf86-video-vmware" \
    "10" "$_GCUnknOpt / xf86-video-fbdev" 2>${ANSWER}

    case $(cat ${ANSWER}) in
        "1") # ATI/AMD
            install_ati
        ;;
        "2") # Intel
            install_intel
        ;;
        "3") # Nouveau / NVIDIA
            [[ $INTEGRATED_GC == "ATI" ]] &&  install_ati || install_intel
            pacstrap ${MOUNTPOINT} xf86-video-nouveau 2>/tmp/.errlog
            sed -i 's/MODULES=""/MODULES="nouveau"/' ${MOUNTPOINT}/etc/mkinitcpio.conf
        ;;
        "4") # NVIDIA-GF
            [[ $INTEGRATED_GC == "ATI" ]] &&  install_ati || install_intel
            arch_chroot "pacman -Rdds --noconfirm mesa-libgl mesa"

            # Set NVIDIA driver(s) to install depending on installed kernel(s)
            ([[ -e ${MOUNTPOINT}/boot/initramfs-linux.img ]] || [[ -e ${MOUNTPOINT}/boot/initramfs-linux-grsec.img ]] || [[ -e ${MOUNTPOINT}/boot/initramfs-linux-zen.img ]]) && NVIDIA="nvidia"
            [[ -e ${MOUNTPOINT}/boot/initramfs-linux-lts.img ]] && NVIDIA="$NVIDIA nvidia-lts"

            clear
            pacstrap ${MOUNTPOINT} ${NVIDIA} nvidia-libgl nvidia-utils pangox-compat nvidia-settings 2>/tmp/.errlog
            NVIDIA_INST=1
        ;;
        "5") # NVIDIA-340
            [[ $INTEGRATED_GC == "ATI" ]] &&  install_ati || install_intel
            arch_chroot "pacman -Rdds --noconfirm mesa-libgl mesa"

            # Set NVIDIA driver(s) to install depending on installed kernel(s)
            ([[ -e ${MOUNTPOINT}/boot/initramfs-linux.img ]] || [[ -e ${MOUNTPOINT}/boot/initramfs-linux-grsec.img ]] || [[ -e ${MOUNTPOINT}/boot/initramfs-linux-zen.img ]]) && NVIDIA="nvidia-340xx"
            [[ -e ${MOUNTPOINT}/boot/initramfs-linux-lts.img ]] && NVIDIA="$NVIDIA nvidia-340xx-lts"

            clear
            pacstrap ${MOUNTPOINT} ${NVIDIA} nvidia-340xx-libgl nvidia-340xx-utils nvidia-settings 2>/tmp/.errlog
            NVIDIA_INST=1
        ;;
        "6") # NVIDIA-304
            [[ $INTEGRATED_GC == "ATI" ]] &&  install_ati || install_intel
            arch_chroot "pacman -Rdds --noconfirm mesa-libgl mesa"

            # Set NVIDIA driver(s) to install depending on installed kernel(s)
            ([[ -e ${MOUNTPOINT}/boot/initramfs-linux.img ]] || [[ -e ${MOUNTPOINT}/boot/initramfs-linux-grsec.img ]] || [[ -e ${MOUNTPOINT}/boot/initramfs-linux-zen.img ]]) && NVIDIA="nvidia-304xx"
            [[ -e ${MOUNTPOINT}/boot/initramfs-linux-lts.img ]] && NVIDIA="$NVIDIA nvidia-304xx-lts"

            clear
            pacstrap ${MOUNTPOINT} ${NVIDIA} nvidia-304xx-libgl nvidia-304xx-utils nvidia-settings 2>/tmp/.errlog
            NVIDIA_INST=1
        ;;
        "7") # Via
            pacstrap ${MOUNTPOINT} xf86-video-openchrome 2>/tmp/.errlog
        ;;
        "8") # VirtualBox
            # Set VB headers to install depending on installed kernel(s)
            [[ -e ${MOUNTPOINT}/boot/initramfs-linux.img ]] && VB_MOD="linux-headers"
            [[ -e ${MOUNTPOINT}/boot/initramfs-linux-grsec.img ]] && VB_MOD="$VB_MOD linux-grsec-headers"
            [[ -e ${MOUNTPOINT}/boot/initramfs-linux-zen.img ]] && VB_MOD="$VB_MOD linux-zen-headers"
            [[ -e ${MOUNTPOINT}/boot/initramfs-linux-lts.img ]] && VB_MOD="$VB_MOD linux-lts-headers"

            DIALOG "$_VBoxInstTitle" --msgbox "$_VBoxInstBody" 0 0
            clear

            pacstrap ${MOUNTPOINT} virtualbox-guest-utils virtualbox-guest-dkms $VB_MOD 2>/tmp/.errlog

            # Load modules and enable vboxservice.
            arch_chroot "modprobe -a vboxguest vboxsf vboxvideo"
            arch_chroot "systemctl enable vboxservice"
            echo -e "vboxguest\nvboxsf\nvboxvideo" > ${MOUNTPOINT}/etc/modules-load.d/virtualbox.conf
        ;;
        "9") # VMWare
            pacstrap ${MOUNTPOINT} xf86-video-vmware xf86-input-vmmouse 2>/tmp/.errlog
        ;;
        "10") # Generic / Unknown
            pacstrap ${MOUNTPOINT} xf86-video-fbdev 2>/tmp/.errlog
        ;;
        *) install_graphics_menu
        ;;
    esac
    check_for_error

    # Create a basic xorg configuration file for NVIDIA proprietary drivers where installed
    # if that file does not already exist.
    if [[ $NVIDIA_INST == 1 ]] && [[ ! -e ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf ]]; then
        echo "Section "\"Device"\"" >> ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
        echo "        Identifier "\"Nvidia Card"\"" >> ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
        echo "        Driver "\"nvidia"\"" >> ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
        echo "        VendorName "\"NVIDIA Corporation"\"" >> ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
        echo "        Option "\"NoLogo"\" "\"true"\"" >> ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
        echo "        #Option "\"UseEDID"\" "\"false"\"" >> ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
        echo "        #Option "\"ConnectedMonitor"\" "\"DFP"\"" >> ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
        echo "        # ..." >> ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
        echo "EndSection" >> ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
    fi

    # Where NVIDIA has been installed allow user to check and amend the file
    if [[ $NVIDIA_INST == 1 ]]; then
        DIALOG " $_NvidiaConfTitle " --msgbox "$_NvidiaConfBody" 0 0
        nano ${MOUNTPOINT}/etc/X11/xorg.conf.d/20-nvidia.conf
    fi

    install_graphics_menu
}

install_de_wm() {
    # Only show this information box once
    if [[ $SHOW_ONCE -eq 0 ]]; then
        DIALOG " $_InstDETitle " --msgbox "$_DEInfoBody" 0 0
        SHOW_ONCE=1
    fi

    # DE/WM Menu
    DIALOG " $_InstDETitle " --checklist "$_InstDEBody $_UseSpaceBar" 0 0 12 \
    "cinnamon" "-" off \
    "deepin" "-" off \
    "deepin-extra" "-" off \
    "enlightenment + terminology" "-" off \
    "gnome-shell" "-" off \
    "gnome" "-" off \
    "gnome-extra" "-" off \
    "plasma-desktop" "-" off \
    "plasma" "-" off \
    "kde-applications" "-" off \
    "lxde" "-" off \
    "lxqt + oxygen-icons" "-" off \
    "mate" "-" off \
    "mate-extra" "-" off \
    "mate-gtk3" "-" off \
    "mate-extra-gtk3" "-" off \
    "xfce4" "-" off \
    "xfce4-goodies" "-" off \
    "awesome + vicious" "-" off \
    "fluxbox + fbnews" "-" off \
    "i3-wm + i3lock + i3status" "-" off \
    "icewm + icewm-themes" "-" off \
    "openbox + openbox-themes" "-" off \
    "pekwm + pekwm-themes" "-" off \
    "windowmaker" "-" off 2>${PACKAGES}

    # If something has been selected, install
    if [[ $(cat ${PACKAGES}) != "" ]]; then
        clear
        sed -i 's/+\|\"//g' ${PACKAGES}
        pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog
        check_for_error

        # Clear the packages file for installation of "common" packages
        echo "" > ${PACKAGES}

        # Offer to install various "common" packages.
        DIALOG " $_InstComTitle " --checklist "$_InstComBody $_UseSpaceBar" 0 50 14 \
        "bash-completion" "-" on \
        "gamin" "-" on \
        "gksu" "-" on \
        "gnome-icon-theme" "-" on \
        "gnome-keyring" "-" on \
        "gvfs" "-" on \
        "gvfs-afc" "-" on \
        "gvfs-smb" "-" on \
        "polkit" "-" on \
        "poppler" "-" on \
        "python2-xdg" "-" on \
        "ntfs-3g" "-" on \
        "ttf-dejavu" "-" on \
        "xdg-user-dirs" "-" on \
        "xdg-utils" "-" on \
        "xterm" "-" on 2>${PACKAGES}

        # If at least one package, install.
        if [[ $(cat ${PACKAGES}) != "" ]]; then
            clear
            pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog
            check_for_error
        fi
    fi
}

# Display Manager
install_dm() {
    # Save repetition of code
    enable_dm() {
        arch_chroot "systemctl enable $(cat ${PACKAGES})" 2>/tmp/.errlog
        check_for_error
        DM=$(cat ${PACKAGES})
        DM_ENABLED=1
    }

    if [[ $DM_ENABLED -eq 0 ]]; then
        # Prep variables
        echo "" > ${PACKAGES}
        dm_list="gdm lxdm lightdm sddm"
        DM_LIST=""
        DM_INST=""

        # Generate list of DMs installed with DEs, and a list for selection menu
        for i in ${dm_list}; do
            [[ -e ${MOUNTPOINT}/usr/bin/${i} ]] && DM_INST="${DM_INST} ${i}"
            DM_LIST="${DM_LIST} ${i} -"
        done

        DIALOG " $_DmChTitle " --menu "$_AlreadyInst$DM_INST\n\n$_DmChBody" 0 0 4 \
        ${DM_LIST} 2>${PACKAGES}
        clear

        # If a selection has been made, act
        if [[ $(cat ${PACKAGES}) != "" ]]; then

            # check if selected dm already installed. If so, enable and break loop.
            for i in ${DM_INST}; do
                if [[ $(cat ${PACKAGES}) == ${i} ]]; then
                    enable_dm
                    break;
                fi
            done

            # If no match found, install and enable DM
            if [[ $DM_ENABLED -eq 0 ]]; then

                # Where lightdm selected, add gtk greeter package
                sed -i 's/lightdm/lightdm lightdm-gtk-greeter/' ${PACKAGES}
                pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog

                # Where lightdm selected, now remove the greeter package
                sed -i 's/lightdm-gtk-greeter//' ${PACKAGES}
                enable_dm
            fi
        fi
    fi

    # Show after successfully installing or where attempting to repeat when already completed.
    [[ $DM_ENABLED -eq 1 ]] && DIALOG " $_DmChTitle " --msgbox "$_DmDoneBody" 0 0
}

# Network Manager
install_nm() {
    # Save repetition of code
    enable_nm() {
        if [[ $(cat ${PACKAGES}) == "NetworkManager" ]]; then
            arch_chroot "systemctl enable NetworkManager.service && systemctl enable NetworkManager-dispatcher.service" >/tmp/.symlink 2>/tmp/.errlog
        else
            arch_chroot "systemctl enable $(cat ${PACKAGES})" 2>/tmp/.errlog
        fi

        check_for_error
        NM_ENABLED=1
    }

    if [[ $NM_ENABLED -eq 0 ]]; then
        # Prep variables
        echo "" > ${PACKAGES}
        nm_list="connman CLI dhcpcd CLI netctl CLI NetworkManager GUI wicd GUI"
        NM_LIST=""
        NM_INST=""

        # Generate list of DMs installed with DEs, and a list for selection menu
        for i in ${nm_list}; do
            [[ -e ${MOUNTPOINT}/usr/bin/${i} ]] && NM_INST="${NM_INST} ${i}"
            NM_LIST="${NM_LIST} ${i}"
        done

        # Remove netctl from selectable list as it is a PITA to configure via arch_chroot
        NM_LIST=$(echo $NM_LIST | sed "s/netctl CLI//")

        DIALOG " $_InstNMTitle " --menu "$_AlreadyInst $NM_INST\n$_InstNMBody" 0 0 4 \
        ${NM_LIST} 2> ${PACKAGES}
        clear

        # If a selection has been made, act
        if [[ $(cat ${PACKAGES}) != "" ]]; then
            # check if selected nm already installed. If so, enable and break loop.
            for i in ${NM_INST}; do
                [[ $(cat ${PACKAGES}) == ${i} ]] && enable_nm && break
            done

            # If no match found, install and enable NM
            if [[ $NM_ENABLED -eq 0 ]]; then

                # Where networkmanager selected, add network-manager-applet
                sed -i 's/NetworkManager/networkmanager network-manager-applet/g' ${PACKAGES}
                pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog

                # Where networkmanager selected, now remove network-manager-applet
                sed -i 's/networkmanager network-manager-applet/NetworkManager/g' ${PACKAGES}
                enable_nm
            fi
        fi
    fi

    # Show after successfully installing or where attempting to repeat when already completed.
    [[ $NM_ENABLED -eq 1 ]] && DIALOG " $_InstNMTitle " --msgbox "$_InstNMErrBody" 0 0
}

install_multimedia_menu(){

    install_alsa_pulse(){
        # Prep Variables
        echo "" > ${PACKAGES}
        ALSA=""
        PULSE_EXTRA=""
        alsa=$(pacman -Ss alsa | awk '{print $1}' | grep "/alsa-" | sed "s/extra\///g" | sort -u)
        pulse_extra=$(pacman -Ss pulseaudio- | awk '{print $1}' | sed "s/extra\///g" | grep "pulseaudio-" | sort -u)

        for i in ${alsa}; do
            ALSA="${ALSA} ${i} - off"
        done

        ALSA=$(echo $ALSA | sed "s/alsa-utils - off/alsa-utils - on/g" | sed "s/alsa-plugins - off/alsa-plugins - on/g")

        for i in ${pulse_extra}; do
            PULSE_EXTRA="${PULSE_EXTRA} ${i} - off"
        done

        DIALOG " $_InstMulSnd " --checklist "$_InstMulSndBody\n\n$_UseSpaceBar" 0 0 14 \
        $ALSA "pulseaudio" "-" off $PULSE_EXTRA \
        "paprefs" "pulseaudio GUI" off \
        "pavucontrol" "pulseaudio GUI" off \
        "ponymix" "pulseaudio CLI" off \
        "volumeicon" "ALSA GUI" off \
        "volwheel" "ASLA GUI" off 2>${PACKAGES}

        clear
        # If at least one package, install.
        if [[ $(cat ${PACKAGES}) != "" ]]; then
            pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog
            check_for_error
        fi
    }

    install_codecs(){
        # Prep Variables
        echo "" > ${PACKAGES}
        GSTREAMER=""
        gstreamer=$(pacman -Ss gstreamer | awk '{print $1}' | grep "/gstreamer" | sed "s/extra\///g" | sed "s/community\///g" | sort -u)
        echo $gstreamer
        for i in ${gstreamer}; do
            GSTREAMER="${GSTREAMER} ${i} - off"
        done

        DIALOG " $_InstMulCodec " --checklist "$_InstMulCodBody$_UseSpaceBar" 0 0 14 \
        $GSTREAMER "xine-lib" "-" off 2>${PACKAGES}

        # If at least one package, install.
        if [[ $(cat ${PACKAGES}) != "" ]]; then
            pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog
            check_for_error
        fi
    }

    install_cust_pkgs(){
        echo "" > ${PACKAGES}
        DIALOG " $_InstMulCust " --inputbox "$_InstMulCustBody" 0 0 "" 2>${PACKAGES} || install_multimedia_menu

        clear
        # If at least one package, install.
        if [[ $(cat ${PACKAGES}) != "" ]]; then
            if [[ $(cat ${PACKAGES}) == "hen poem" ]]; then
                DIALOG " \"My Sweet Buckies\" by Atiya & Carl " --msgbox "\nMy Sweet Buckies,\nYou are the sweetest Buckies that ever did \"buck\",\nLily, Rosie, Trumpet, and Flute,\nMy love for you all is absolute!\n\nThey buck: \"We love our treats, we are the Booyakka sisters,\"\n\"Sometimes we squabble and give each other comb-twisters,\"\n\"And in our garden we love to sunbathe, forage, hop and jump,\"\n\"We love our freedom far, far away from that factory farm dump,\"\n\n\"For so long we were trapped in cramped prisons full of disease,\"\n\"No sunlight, no fresh air, no one who cared for even our basic needs,\"\n\"We suffered in fear, pain, and misery for such a long time,\"\n\"But now we are so happy, we wanted to tell you in this rhyme!\"\n\n" 0 0
            else
                pacstrap ${MOUNTPOINT} $(cat ${PACKAGES}) 2>/tmp/.errlog
                check_for_error
            fi
        fi

    }

    if [[ $SUB_MENU != "install_multimedia_menu" ]]; then
        SUB_MENU="install_multimedia_menu"
        HIGHLIGHT_SUB=1
    else
        if [[ $HIGHLIGHT_SUB != 5 ]]; then
            HIGHLIGHT_SUB=$(( HIGHLIGHT_SUB + 1 ))
        fi
    fi

    dialog --default-item ${HIGHLIGHT_SUB} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_InstMultMenuTitle " --menu "$_InstMultMenuBody" 0 0 5 \
    "1" "$_InstMulSnd" \
    "2" "$_InstMulCodec" \
    "3" "$_InstMulAcc" \
    "4" "$_InstMulCust" \
    "5" "$_Back" 2>${ANSWER}

    HIGHLIGHT_SUB=$(cat ${ANSWER})
    case $(cat ${ANSWER}) in
        "1") install_alsa_pulse
        ;;
        "2") install_codecs
        ;;
        "3") install_acc_menu
        ;;
        "4") install_cust_pkgs
        ;;
        *) main_menu_online
        ;;
    esac

    install_multimedia_menu
}

security_menu(){
    if [[ $SUB_MENU != "security_menu" ]]; then
        SUB_MENU="security_menu"
        HIGHLIGHT_SUB=1
    else
        if [[ $HIGHLIGHT_SUB != 4 ]]; then
            HIGHLIGHT_SUB=$(( HIGHLIGHT_SUB + 1 ))
        fi
    fi

    dialog --default-item ${HIGHLIGHT_SUB} --backtitle "$VERSION - $SYSTEM ($ARCHI)" --title " $_SecMenuTitle " --menu "$_SecMenuBody" 0 0 4 \
    "1" "$_SecJournTitle" \
    "2" "$_SecCoreTitle" \
    "3" "$_SecKernTitle" \
    "4" "$_Back" 2>${ANSWER}

    HIGHLIGHT_SUB=$(cat ${ANSWER})
    case $(cat ${ANSWER}) in
        "1") # systemd-journald
            DIALOG " $_SecJournTitle " --menu "$_SecJournBody" 0 0 7 \
            "$_Edit" "/etc/systemd/journald.conf" \
            "10M" "SystemMaxUse=10M" \
            "20M" "SystemMaxUse=20M" \
            "50M" "SystemMaxUse=50M" \
            "100M" "SystemMaxUse=100M" \
            "200M" "SystemMaxUse=200M" \
            "$_Disable" "Storage=none" 2>${ANSWER}

            if [[ $(cat ${ANSWER}) != "" ]]; then
                if  [[ $(cat ${ANSWER}) == "$_Disable" ]]; then
                    sed -i "s/#Storage.*\|Storage.*/Storage=none/g" ${MOUNTPOINT}/etc/systemd/journald.conf
                    sed -i "s/SystemMaxUse.*/#&/g" ${MOUNTPOINT}/etc/systemd/journald.conf
                    DIALOG " $_SecJournTitle " --infobox "\n$_Done!\n\n" 0 0
                    sleep 2
                elif [[ $(cat ${ANSWER}) == "$_Edit" ]]; then
                    nano ${MOUNTPOINT}/etc/systemd/journald.conf
                else
                    sed -i "s/#Storage.*\|Storage.*/Storage=$(cat ${ANSWER})/g" ${MOUNTPOINT}/etc/systemd/journald.conf
                    sed -i "s/SystemMaxUse.*/#&/g" ${MOUNTPOINT}/etc/systemd/journald.conf
                    DIALOG " $_SecJournTitle " --infobox "\n$_Done!\n\n" 0 0
                    sleep 2
                fi
            fi
        ;;
        "2") # core dump
            DIALOG " $_SecCoreTitle " --menu "$_SecCoreBody" 0 0 2 \
            "$_Disable" "Storage=none" "$_Edit" "/etc/systemd/coredump.conf" 2>${ANSWER}

            if [[ $(cat ${ANSWER}) == "$_Disable" ]]; then
                sed -i "s/#Storage.*\|Storage.*/Storage=none/g" ${MOUNTPOINT}/etc/systemd/coredump.conf
                DIALOG " $_SecCoreTitle " --infobox "\n$_Done!\n\n" 0 0
                sleep 2
            elif [[ $(cat ${ANSWER}) == "$_Edit" ]]; then
                nano ${MOUNTPOINT}/etc/systemd/coredump.conf
            fi
        ;;
        "3") # Kernel log access
            DIALOG " $_SecKernTitle " --menu "\nKernel logs may contain information an attacker can use to identify and exploit kernel vulnerabilities, including sensitive memory addresses.\n\nIf systemd-journald logging has not been disabled, it is possible to create a rule in /etc/sysctl.d/ to disable access to these logs unless using root privilages (e.g. via sudo).\n" 0 0 2 \
            "$_Disable" "kernel.dmesg_restrict = 1" "$_Edit" "/etc/systemd/coredump.conf.d/custom.conf" 2>${ANSWER}

            case $(cat ${ANSWER}) in
                "$_Disable")
                    echo "kernel.dmesg_restrict = 1" > ${MOUNTPOINT}/etc/sysctl.d/50-dmesg-restrict.conf
                    DIALOG " $_SecKernTitle " --infobox "\n$_Done!\n\n" 0 0
                sleep 2 ;;
                "$_Edit")
                    [[ -e ${MOUNTPOINT}/etc/sysctl.d/50-dmesg-restrict.conf ]] && nano ${MOUNTPOINT}/etc/sysctl.d/50-dmesg-restrict.conf \
                || DIALOG " $_SeeConfErrTitle " --msgbox "$_SeeConfErrBody1" 0 0 ;;
            esac
        ;;
        *) main_menu_online
        ;;
    esac

    security_menu
}

install_base_offline(){

    clear

    # Change installation method depending on use of img or sfs
    if [[ -e /run/archiso/sfs/airootfs/airootfs.img ]]; then
        AIROOTIMG="/run/archiso/sfs/airootfs/airootfs.img"
        mkdir -p ${BYPASS} 2>/tmp/.errlog
        mount ${AIROOTIMG} ${BYPASS} 2>>/tmp/.errlog
        rsync -a --progress ${BYPASS} ${MOUNTPOINT}/ 2>>/tmp/.errlog
        umount -l ${BYPASS}
    else
        AIROOTIMG="/run/archiso/sfs/airootfs/"
        rsync -a --progress ${AIROOTIMG} ${MOUNTPOINT}/ 2>/tmp/.errlog
    fi

    check_for_error

    # Keyboard config for vc and x11
    [[ -e /tmp/vconsole.conf ]] && cp /tmp/vconsole.conf ${MOUNTPOINT}/etc/vconsole.conf 2>>/tmp/.errlog
    [[ -e /tmp/01-keyboard-layout.conf ]] && cp -f /tmp/01-keyboard-layout.conf ${MOUNTPOINT}/etc/X11/xorg.conf.d/$(ls ${MOUNTPOINT}/etc/X11/xorg.conf.d/ | grep "keyboard") 2>>/tmp/.errlog

    # set up kernel for mkiniticpio
    cp /run/archiso/bootmnt/arch/boot/${ARCHI}/vmlinuz ${MOUNTPOINT}/boot/vmlinuz-linux 2>>/tmp/.errlog

    # copy over new mirrorlist
    cp /etc/pacman.d/mirrorlist ${MOUNTPOINT}/etc/pacman.d/mirrorlist 2>>/tmp/.errlog

    # Clean up installation
    [[ -d ${MOUNTPOINT}/abif-master ]] && rm -R ${MOUNTPOINT}/abif-master 2>>/tmp/.errlog
    rm -rf ${MOUNTPOINT}/vomi 2>>/tmp/.errlog
    rm -rf ${BYPASS} 2>>/tmp/.errlog
    rm -rf ${MOUNTPOINT}/source 2>>/tmp/.errlog
    rm -rf ${MOUNTPOINT}/src 2>>/tmp/.errlog
    rmdir ${MOUNTPOINT}/bypass 2>>/tmp/.errlog
    rmdir ${MOUNTPOINT}/src 2>>/tmp/.errlog
    rmdir ${MOUNTPOINT}/source 2>>/tmp/.errlog
    rm -f ${MOUNTPOINT}/etc/sudoers.d/g_wheel 2>>/tmp/.errlog
    rm -f ${MOUNTPOINT}/var/lib/NetworkManager/NetworkManager.state 2>>/tmp/.errlog
    rm -f ${MOUNTPOINT}/update-abif 2>>/tmp/.errlog
    sed -i 's/.*pam_wheel\.so/#&/' ${MOUNTPOINT}/etc/pam.d/su 2>>/tmp/.errlog

    # clean out archiso files from install
    find ${MOUNTPOINT}/usr/lib/initcpio -name archiso* -type f -exec rm '{}' \;

    # systemd
    rm -R ${MOUNTPOINT}/etc/systemd/system/getty@tty1.service.d 2>>/tmp/.errlog
    rm ${MOUNTPOINT}/etc/systemd/system/default.target 2>>/tmp/.errlog

    # Journal
    sed -i 's/volatile/auto/g' ${MOUNTPOINT}/etc/systemd/journald.conf 2>>/tmp/.errlog

    # Stop pacman complaining
    arch_chroot "mkdir -p /var/lib/pacman/sync" 2>>/tmp/.errlog
    arch_chroot "touch /var/lib/pacman/sync/{core.db,extra.db,community.db}" 2>>/tmp/.errlog

    # Fix NetworkManager
    arch_chroot "systemctl enable NetworkManager -f" 2>>/tmp/.errlog

    # Keyboard config for vc and x11
    [[ -e /tmp/vconsole.conf ]] && cp /tmp/vconsole.conf ${MOUNTPOINT}/etc/vconsole.conf 2>>/tmp/.errlog
    [[ -e /tmp/01-keyboard-layout.conf ]] && cp -f /tmp/01-keyboard-layout.conf ${MOUNTPOINT}/etc/X11/xorg.conf.d/$(ls ${MOUNTPOINT}/etc/X11/xorg.conf.d/ | grep "keyboard") 2>>/tmp/.errlog

    # Display Manager
    arch_chroot "systemctl enable lightdm" 2>>/tmp/.errlog
    cp -f /etc/lightdm/lightdm.conf ${MOUNTPOINT}/etc/lightdm/lightdm.conf 2>>/tmp/.errlog
    [[ -d ${MOUNTPOINT}/inst ]] && rm -R ${MOUNTPOINT}/inst &> /dev/null 2>>/tmp/.errlog
    check_for_error

    # Virtualbox Guest
    [[ $(lspci | grep -i "vga" | sed 's/.*://' | sed 's/(.*//' | sed 's/^[ \t]*//' | grep -i "virtualbox") != "" ]] && arch_chroot "systemctl enable vboxservice"
}
