# !/bin/bash
#
# Antergos Architect Installation Framework
#
# Original work by Carl Duff for Architect Linux v2.2.1 (2016)
# Modified for Antergos by Karasu (karasu@antergos.com) (2017)
#
# This program is free software, provided under the GNU General Public License
# as published by the Free Software Foundation. So feel free to copy, distribute,
# or modify it as you wish.

# XML Parsing

read_xml_dom () {
    local IFS=\>
    read -d \< ENTITY CONTENT
    local ret=$?
    TAG_NAME=${ENTITY%% *}
    ATTRIBUTES=${ENTITY#* }
    return $ret
}


parse_xml_dom () {
    if [[ $TAG_NAME = "pkgname" && "$OUR_EDITION" == "1" ]]; then
        eval local $ATTRIBUTES
        echo $CONTENT >> $OUT_FILE
        #if [[ "$lib" != "" ]]; then
        #    echo "pkgname lib is: $lib"
        #fi
        #if [[ "$lang" != "" ]]; then
        #    echo "pkgname lang is: $lang"
        #fi
    elif [[ $TAG_NAME = "edition" ]]; then
        eval local $ATTRIBUTES
        if [[ $EDITIONS == *"$name"* ]]; then
            OUR_EDITION=1
        else
            OUR_EDITION=0
        fi
    fi
}

setup_profiles() {
    # setup profiles with xml file
    PROFILES="${DATADIR}/profiles"
    #clear

    curl -o ${XML_TMP} -Ls ${XML_URL}
    #check_for_error "pull profiles repo" $?

    mkdir -p ${PROFILES}

    for EDITIONS in "${DESKTOPS[@]}"
    do
        OUT_FILE=${PROFILES}"/antergos-$EDITIONS"

        if [[ "$EDITIONS" == "base" ]]; then
            EDITIONS="common base"
        else
            EDITIONS="common graphic "$EDITIONS
        fi

        OUR_EDITION=0

        while read_xml_dom; do
            parse_xml_dom
        done < $XML_TMP
    done
}
