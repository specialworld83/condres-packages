# !/bin/bash
#
# Antergos Architect Installation Framework
#
# Original work by Carl Duff for Architect Linux v2.2.1 (2016)
# Modified for Antergos by Karasu (karasu@antergos.com) (2017)
#
# This program is free software, provided under the GNU General Public License
# as published by the Free Software Foundation. So feel free to copy, distribute,
# or modify it as you wish.

######################################################################
##                                                                  ##
##                        Core Functions                            ##
##                                                                  ##
######################################################################

import(){
    if [[ -r $1 ]];then
        source $1
    else
        echo "Could not import $1"
    fi
}

DIALOG() {
    dialog --backtitle "$BACK_TITLE - $SYSTEM System ($ARCHI)" --column-separator "|" --exit-label "$_Back" --title "$@"
}

# Add locale on-the-fly and sets source translation file for installer
select_language() {
    DIALOG " Select Language " --menu "\nLanguage / sprache / taal / språk / lingua / idioma / nyelv / língua" 0 0 9 \
    "1" $"English            (en_**)" \
    "2" $"Español            (es_ES)" \
    "3" $"Português [Brasil] (pt_BR)" \
    "4" $"Português          (pt_PT)" \
    "5" $"Français           (fr_FR)" \
    "6" $"Russkiy            (ru_RU)" \
    "7" $"Italiano           (it_IT)" \
    "8" $"Nederlands         (nl_NL)" \
    "9" $"Magyar             (hu_HU)" 2>${ANSWER}

    case $(cat ${ANSWER}) in
        "1") source ${TRANSDIR}/english.trans
            CURR_LOCALE="en_US.UTF-8"
        ;;
        "2") source ${TRANSDIR}/spanish.trans
            CURR_LOCALE="es_ES.UTF-8"
        ;;
        "3") source ${TRANSDIR}/portuguese_brasil.trans
            CURR_LOCALE="pt_BR.UTF-8"
        ;;
        "4") source ${TRANSDIR}/portuguese.trans
            CURR_LOCALE="pt_PT.UTF-8"
        ;;
        "5") source ${TRANSDIR}/french.trans
            CURR_LOCALE="fr_FR.UTF-8"
        ;;
        "6") source ${TRANSDIR}/russian.trans
            CURR_LOCALE="ru_RU.UTF-8"
            FONT="LatKaCyrHeb-14.psfu"
        ;;
        "7") source ${TRANSDIR}/italian.trans
            CURR_LOCALE="it_IT.UTF-8"
        ;;
        "8") source ${TRANSDIR}/dutch.trans
            CURR_LOCALE="nl_NL.UTF-8"
        ;;
        "9") source ${TRANSDIR}/hungarian.trans
            CURR_LOCALE="hu_HU.UTF-8"
            FONT="lat2-16.psfu"
        ;;
        *) exit 0
        ;;
    esac

    # Generate the chosen locale and set the language
    sed -i '' 's/^\([^#]\)/#\1/g' /etc/locale.gen
    sed -i "s/#en_US.UTF-8/en_US.UTF-8/" /etc/locale.gen
    sed -i "s/#${CURR_LOCALE}/${CURR_LOCALE}/" /etc/locale.gen
    locale-gen >/dev/null 2>&1
    export LANG=${CURR_LOCALE}
    [[ $FONT != "" ]] && setfont $FONT
}

# Check user is root, and that there is an active internet connection
# Checks are in different "if" statements for readability.
check_requirements() {
    DIALOG " $_ChkTitle " --infobox "$_ChkBody" 0 0
    sleep 2

    if [[ `whoami` != "root" ]]; then
        DIALOG " $_Erritle " --infobox "$_RtFailBody" 0 0
        sleep 3
        clear
        exit 1
    fi

    if [[ ! $(ping -c 1 google.com) ]]; then
        DIALOG " $_ErrTitle " --infobox "$_ConFailBody" 0 0
        sleep 3
        clear
        exit 1
    fi

    # This will only be executed where neither of the above checks are true.
    # The error log is also cleared, just in case something is there from a previous use of the installer.
    DIALOG " $_ReqMetTitle " --infobox "$_ReqMetBody" 0 0
    sleep 3
    clear
    echo "" > /tmp/.errlog
    pacman -Syy
}

# Adapted from AIS. Checks if system is made by Apple, whether the system is BIOS or UEFI,
# and for LVM and/or LUKS.
id_system() {
    # Apple System Detection
    if [[ "$(cat /sys/class/dmi/id/sys_vendor)" == 'Apple Inc.' ]] || [[ "$(cat /sys/class/dmi/id/sys_vendor)" == 'Apple Computer, Inc.' ]]; then
        modprobe -r -q efivars || true  # if MAC
    else
        modprobe -q efivarfs            # all others
    fi

    # BIOS or UEFI Detection
    if [[ -d "/sys/firmware/efi/" ]]; then
        # Mount efivarfs if it is not already mounted
        if [[ -z $(mount | grep /sys/firmware/efi/efivars) ]]; then
            mount -t efivarfs efivarfs /sys/firmware/efi/efivars
        fi
        SYSTEM="UEFI"
    else
        SYSTEM="BIOS"
    fi
}

# Adapted from AIS. An excellent bit of code!
arch_chroot() {
    arch-chroot $MOUNTPOINT /bin/bash -c "${1}"
}

# If there is an error, display it, clear the log and then go back to the main menu (no point in continuing).
check_for_error() {
    if [[ $? -eq 1 ]] && [[ $(cat /tmp/.errlog | grep -i "error") != "" ]]; then
        DIALOG " $_ErrTitle " --msgbox "$(cat /tmp/.errlog)" 0 0
        echo "" > /tmp/.errlog
        main_menu_online
    fi
}


# Ensure that a partition is mounted
check_mount() {
    if [[ $(lsblk -o MOUNTPOINT | grep ${MOUNTPOINT}) == "" ]]; then
        DIALOG " $_ErrTitle " --msgbox "$_ErrNoMount" 0 0
        main_menu_online
    fi
}

# Ensure that Arch has been installed
check_base() {
    if [[ ! -e ${MOUNTPOINT}/etc ]]; then
        DIALOG " $_ErrTitle " --msgbox "$_ErrNoBase" 0 0
        main_menu_online
    fi
}

# Simple code to show devices / partitions.
show_devices() {
    lsblk -o NAME,MODEL,TYPE,FSTYPE,SIZE,MOUNTPOINT | grep "disk\|part\|lvm\|crypt\|NAME\|MODEL\|TYPE\|FSTYPE\|SIZE\|MOUNTPOINT" > /tmp/.devlist
    DIALOG " $_DevShowOpt " --textbox /tmp/.devlist 0 0
}
