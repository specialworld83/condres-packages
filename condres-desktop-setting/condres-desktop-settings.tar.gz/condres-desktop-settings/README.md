# Condres Desktop Settings
Condres setup files for several Desktop Environments
