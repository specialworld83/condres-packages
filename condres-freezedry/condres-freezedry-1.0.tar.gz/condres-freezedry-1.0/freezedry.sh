#!/bin/bash
python -m freezedry.run "$@"
